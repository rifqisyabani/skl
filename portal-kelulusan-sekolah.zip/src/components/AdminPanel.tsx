import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Settings,
  Users,
  Trash2,
  Plus,
  RefreshCw,
  Lock,
  Edit2,
  Calendar,
  Save,
  MessageSquare,
  Sparkles,
  ToggleLeft,
  X,
  FileSpreadsheet,
  BookOpen,
  Upload,
  FileText,
  RotateCw,
  Download
} from 'lucide-react';
import { Student, SchoolConfig, GuestbookMessage, GraduationStatus, Subject } from '../types';

interface AdminPanelProps {
  config: SchoolConfig;
  onSaveConfig: (newConfig: SchoolConfig) => void;
  students: Student[];
  onAddStudent: (newStudent: Student) => void;
  onEditStudent: (editedStudent: Student) => void;
  onDeleteStudent: (id: string) => void;
  messages: GuestbookMessage[];
  onDeleteMessage: (id: string) => void;
  onClose: () => void;
}

const DEFAULT_SUBJECTS: Subject[] = [
  { id: 'sbj-1', name: "Al-Qur'an Hadis", code: 'PABP' },
  { id: 'sbj-2', name: 'Pendidikan Pancasila & Kewarganegaraan', code: 'PPKn' },
  { id: 'sbj-3', name: 'Bahasa Indonesia', code: 'IND' },
  { id: 'sbj-4', name: 'Matematika', code: 'MAT-W' },
  { id: 'sbj-5', name: 'Sejarah Kebudayaan Islam (SKI)', code: 'SEJ' },
  { id: 'sbj-6', name: 'Bahasa Inggris', code: 'ING' },
  { id: 'sbj-7', name: 'Ilmu Pengetahuan Alam (IPA)', code: 'FIS' },
  { id: 'sbj-8', name: 'Bahasa Arab', code: 'KIM' },
  { id: 'sbj-9', name: 'Ilmu Pengetahuan Sosial (IPS)', code: 'BIO' },
  { id: 'sbj-10', name: 'Seni Budaya', code: 'SENI' },
  { id: 'sbj-11', name: 'Pendidikan Jasmani, Olahraga & Kesehatan', code: 'PJOK' },
  { id: 'sbj-12', name: 'Prakarya', code: 'PKWU' },
];

export const AdminPanel: React.FC<AdminPanelProps> = ({
  config,
  onSaveConfig,
  students,
  onAddStudent,
  onEditStudent,
  onDeleteStudent,
  messages,
  onDeleteMessage,
  onClose
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [authError, setAuthError] = useState('');

  // Tab controllers within admin
  const [adminTab, setAdminTab] = useState<'config' | 'subjects' | 'students' | 'mading'>('config');

  // Edit / Input configurations
  const [schoolName, setSchoolName] = useState(config.schoolName);
  const [schoolAddress, setSchoolAddress] = useState(config.schoolAddress);
  const [academicYear, setAcademicYear] = useState(config.academicYear);
  const [announcementDate, setAnnouncementDate] = useState(config.announcementDate.substring(0, 16)); // Format for datetime-local input
  const [isReleasedDirectly, setIsReleasedDirectly] = useState(config.isReleasedDirectly);
  const [accreditation, setAccreditation] = useState(config.accreditation);
  const [schoolLogoUrl, setSchoolLogoUrl] = useState(config.schoolLogoUrl || '');

  // Active subjects list state inside AdminPanel (copied from config or defaults)
  const [subjectsList, setSubjectsList] = useState<Subject[]>(
    config.subjects && config.subjects.length > 0 ? config.subjects : DEFAULT_SUBJECTS
  );

  // Helpers to add or delete single subject
  const [newSubName, setNewSubName] = useState('');
  const [newSubCode, setNewSubCode] = useState('');
  const [editingSubId, setEditingSubId] = useState<string | null>(null);

  // Student management state
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);
  const [bulkDataInput, setBulkDataInput] = useState('');

  // Student FORM state
  const [stdName, setStdName] = useState('');
  const [stdNisn, setStdNisn] = useState('');
  const [stdExamNo, setStdExamNo] = useState('');
  const [stdClass, setStdClass] = useState('IX-A');
  const [stdBirthPlace, setStdBirthPlace] = useState('Tasikmalaya');
  const [stdBirthDate, setStdBirthDate] = useState('12 Maret 2011');
  const [stdStatus, setStdStatus] = useState<GraduationStatus>('LULUS');
  const [stdLetterNo, setStdLetterNo] = useState('050/MTs.AWM/V/2026');

  // Custom physical PDF credentials
  const [stdCustomPdfUrl, setStdCustomPdfUrl] = useState('');
  const [stdCustomPdfName, setStdCustomPdfName] = useState('');

  // Dictionary scores input map
  const [studentScores, setStudentScores] = useState<Record<string, number>>({});

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() === 'rifqy.syabani@gmail.com' && password === '081297rms') {
      setIsAdminAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Username atau kata sandi admin salah. Silakan coba kembali.');
    }
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig({
      schoolName,
      schoolAddress,
      academicYear,
      announcementDate: new Date(announcementDate).toISOString(),
      isReleasedDirectly,
      accreditation,
      subjects: subjectsList,
      schoolLogoUrl
    });
    alert('Konfigurasi Pengumuman berhasil disimpan ke Sistem!');
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('File gambar terlalu besar. Maksimum ukuran adalah 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setSchoolLogoUrl(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Keep subjectsList sync when config changes
  React.useEffect(() => {
    if (config.subjects && config.subjects.length > 0) {
      setSubjectsList(config.subjects);
    }
  }, [config.subjects]);

  const activeSubjects = subjectsList.length > 0 ? subjectsList : DEFAULT_SUBJECTS;

  const handleDownloadTemplate = () => {
    // Generate headers
    const headers = [
      'NISN',
      'No_Ujian',
      'Nama_Lengkap',
      'Kelas',
      'Tempat_Lahir',
      'Tgl_Lahir',
      'Status',
      'No_Surat_SKL',
      ...activeSubjects.map((sub) => `Nilai_${sub.code}`)
    ];

    // Dummy examples
    const sample1 = [
      '0012445511',
      'U-MTSWM-2026-003',
      'Rifqy Syabani Pratama',
      'IX-A',
      'Tasikmalaya',
      '20 Maret 2011',
      'LULUS',
      '053/MTs.AWM/V/2026',
      ...activeSubjects.map(() => '92')
    ];

    const sample2 = [
      '0012445522',
      'U-MTSWM-2026-004',
      'Aura Salsabila Rahmi',
      'IX-B',
      'Bandung',
      '15 Mei 2011',
      'LULUS',
      '054/MTs.AWM/V/2026',
      ...activeSubjects.map(() => '85')
    ];

    const rows = [headers, sample1, sample2];
    
    // Excel 'sep=,' directive ensures standard commas are parsed correctly everywhere
    const csvContent = "\uFEFF" + "sep=,\r\n" + rows.map(r => r.map(val => {
      let cleanVal = String(val).replace(/"/g, '""');
      if (cleanVal.includes(',') || cleanVal.includes('"') || cleanVal.includes('\n') || cleanVal.includes(';') || cleanVal.includes('\t')) {
        return `"${cleanVal}"`;
      }
      return cleanVal;
    }).join(',')).join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Template_Impor_Siswa_${config.schoolName.replace(/\s+/g, '_')}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const resetStudentForm = () => {
    setStdName('');
    setStdNisn('');
    setStdExamNo('');
    setStdClass('IX-A');
    setStdBirthPlace('Tasikmalaya');
    setStdBirthDate('12 Maret 2011');
    setStdStatus('LULUS');
    setStdLetterNo(`0${students.length + 51}/MTs.AWM/V/2026`);
    setStdCustomPdfUrl('');
    setStdCustomPdfName('');
    
    // Set all dynamic subjects scores to default 80
    const initialScores: Record<string, number> = {};
    activeSubjects.forEach((sub) => {
      initialScores[sub.code] = 80;
    });
    setStudentScores(initialScores);

    setIsAddingStudent(false);
    setEditingStudentId(null);
  };

  const handleBulkImport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bulkDataInput.trim()) {
      alert('Mohon masukkan data atau tempelkan baris spreadsheet terlebih dahulu.');
      return;
    }

    const lines = bulkDataInput.trim().split('\n');
    const importedStudents: Student[] = [];
    let successCount = 0;
    let errorCount = 0;

    lines.forEach((line, index) => {
      // Clean leading/trailing spaces
      const cleanLine = line.trim();
      if (!cleanLine) return; // Skip empty lines

      // Skip table header if it's there
      if (index === 0 && (cleanLine.toLowerCase().includes('nisn') || cleanLine.toLowerCase().includes('nama'))) {
        return;
      }

      // Detect separator: Tab is highest priority (Excel copy-paste), then semicolon, then comma
      let parts = cleanLine.split('\t');
      if (parts.length < 5) {
        parts = cleanLine.split(';');
      }
      if (parts.length < 5) {
        parts = cleanLine.split(',');
      }

      // We need at least 3 parts (NISN, No_Ujian, Nama) to be minimally valid
      if (parts.length >= 3) {
        const nisn = parts[0]?.trim() || '';
        const examNumber = parts[1]?.trim() || '';
        const name = parts[2]?.trim() || '';
        const className = parts[3]?.trim() || 'IX-A';
        const birthPlace = parts[4]?.trim() || 'Tasikmalaya';
        const birthDate = parts[5]?.trim() || '12 Maret 2011';
        const statusValue = parts[6]?.trim()?.toUpperCase() || 'LULUS';
        const status: GraduationStatus = statusValue.includes('TUNDA') || statusValue.includes('DITUNDA') ? 'DITUNDA' : 'LULUS';
        
        // Custom default or specified letter number
        const letterNumber = parts[7]?.trim() || `0${students.length + importedStudents.length + 51}/MTs.AWM/V/2026`;

        // Scores aligned dynamically starting from column index 8
        const scoresList = activeSubjects.map((sub, sIdx) => {
          const excelColIndex = 8 + sIdx;
          const score = Number(parts[excelColIndex]) || 80;
          return {
            subject: sub.name,
            code: sub.code,
            score
          };
        });

        if (nisn && examNumber && name) {
          importedStudents.push({
            id: `std-${Date.now()}-${successCount}`,
            name,
            nisn,
            examNumber,
            className,
            birthPlace,
            birthDate,
            status,
            letterNumber,
            scores: scoresList,
            schoolName: config.schoolName,
            principalName: 'H. Muhammad Yusuf, S.Ag., M.Pd.I.',
            principalNip: '19780512 200501 1 002'
          });
          successCount++;
        } else {
          errorCount++;
        }
      } else {
        errorCount++;
      }
    });

    if (importedStudents.length > 0) {
      importedStudents.forEach((std) => onAddStudent(std));
      alert(`Sukses mengimpor ${successCount} data siswa ke database! ${errorCount > 0 ? `(${errorCount} baris tidak pas diabaikan)` : ''}`);
      setBulkDataInput('');
      setIsBulkImportOpen(false);
    } else {
      alert('Impor gagal. Pastikan data terekam dengan separator kolom yang benar (Kolom dipisah Tab/Koma/Titik-koma).');
    }
  };

  const handleCreateOrEditStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stdName.trim() || !stdNisn.trim() || !stdExamNo.trim() || !stdLetterNo.trim()) {
      alert('Mohon lengkapi semua isian wajib siswa.');
      return;
    }

    const scoresList = activeSubjects.map((sub) => ({
      subject: sub.name,
      code: sub.code,
      score: studentScores[sub.code] ?? 80
    }));

    if (editingStudentId) {
      // EDITING
      const original = students.find((x) => x.id === editingStudentId);
      if (!original) return;

      onEditStudent({
        ...original,
        name: stdName.trim(),
        nisn: stdNisn.trim(),
        examNumber: stdExamNo.trim(),
        className: stdClass,
        birthPlace: stdBirthPlace,
        birthDate: stdBirthDate,
        status: stdStatus,
        letterNumber: stdLetterNo.trim(),
        scores: scoresList,
        customPdfUrl: stdCustomPdfUrl.trim() || undefined,
        customPdfName: stdCustomPdfName.trim() || undefined
      });
      alert('Data Siswa berhasil diperbaharui!');
    } else {
      // CREATING NEW
      const newStd: Student = {
        id: `std-${Date.now()}`,
        name: stdName.trim(),
        nisn: stdNisn.trim(),
        examNumber: stdExamNo.trim(),
        className: stdClass,
        birthPlace: stdBirthPlace,
        birthDate: stdBirthDate,
        status: stdStatus,
        letterNumber: stdLetterNo.trim(),
        scores: scoresList,
        schoolName: config.schoolName,
        principalName: 'H. Muhammad Yusuf, S.Ag., M.Pd.I.',
        principalNip: '19780512 200501 1 002',
        customPdfUrl: stdCustomPdfUrl.trim() || undefined,
        customPdfName: stdCustomPdfName.trim() || undefined
      };
      onAddStudent(newStd);
      alert('Siswa Baru sukses ditambahkan ke pangkalan data.');
    }

    resetStudentForm();
  };

  const handleTriggerEdit = (std: Student) => {
    setEditingStudentId(std.id);
    setStdName(std.name);
    setStdNisn(std.nisn);
    setStdExamNo(std.examNumber);
    setStdClass(std.className);
    setStdBirthPlace(std.birthPlace);
    setStdBirthDate(std.birthDate);
    setStdStatus(std.status);
    setStdLetterNo(std.letterNumber);
    setStdCustomPdfUrl(std.customPdfUrl || '');
    setStdCustomPdfName(std.customPdfName || '');

    // Populate dynamic scores map
    const scoresMap: Record<string, number> = {};
    activeSubjects.forEach((sub) => {
      const found = std.scores.find((x) => x.code === sub.code || x.subject === sub.name);
      scoresMap[sub.code] = found ? found.score : 80;
    });
    setStudentScores(scoresMap);

    setIsAddingStudent(true); // Open panel
  };

  // Preset countdown timers for grading ease
  const setPresetTime = (minutesFromNow: number) => {
    const d = new Date();
    d.setMinutes(d.getMinutes() + minutesFromNow);
    // Format to yyyy-MM-ddThh:mm
    const dateStr = d.toISOString().substring(0, 16);
    setAnnouncementDate(dateStr);
  };

  return (
    <div id="admin-panel-container" className="w-full max-w-6xl mx-auto bg-white rounded-2xl border border-gray-200 shadow-xl overflow-hidden print:hidden">
      {/* Admin Module Banner */}
      <div className="bg-emerald-950 text-white p-5 md:p-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-400 rounded-lg flex items-center justify-center text-emerald-950 font-bold">
            <Lock className="w-5 h-5 fill-current" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">Pusat Administrasi & Kontral Data (SIKS)</h2>
            <p className="text-xs text-amber-300 font-mono font-bold uppercase">Akses khusus kepala madrasah & tim kurikulum MTs KH. A. Wahab Muhsin</p>
          </div>
        </div>

        <button
          id="close-admin-btn"
          onClick={onClose}
          className="text-gray-400 hover:text-white bg-emerald-900 hover:bg-emerald-850 p-2 rounded-xl transition-all cursor-pointer"
          title="Keluar"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Auth Screen Overlay */}
      {!isAdminAuthenticated ? (
        <div className="p-8 md:p-12 text-center max-w-md mx-auto space-y-6">
          <div className="w-16 h-16 bg-emerald-50 text-emerald-800 rounded-full flex items-center justify-center mx-auto shadow-inner">
            <Lock className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-gray-900">Masuk Hak Akses Guru / Admin</h3>
            <p className="text-xs text-gray-500 font-sans leading-relaxed">
              Silakan masukkan kata sandi penguji kelulusan untuk membuka utilitas manipulasi data siswa, konfigurasi countdown, dan mading.
            </p>
          </div>

          <form onSubmit={handleAdminAuth} className="space-y-3">
            <div>
              <label htmlFor="admin-user-input" className="sr-only">Username / Email Admin</label>
              <input
                id="admin-user-input"
                type="text"
                placeholder="Masukkan username atau email..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 focus:bg-white focus:border-emerald-600 rounded-xl focus:outline-none transition-all font-mono text-sm"
              />
            </div>
            <div>
              <label htmlFor="admin-pass-input" className="sr-only">Password Admin</label>
              <input
                id="admin-pass-input"
                type="password"
                placeholder="Masukkan password..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 focus:bg-white focus:border-emerald-600 rounded-xl focus:outline-none transition-all font-mono text-sm"
              />
            </div>

            {authError && (
              <p className="text-xs text-rose-600 font-semibold font-mono text-center">
                ⚠ {authError}
              </p>
            )}

            <button
              id="submit-auth-btn"
              type="submit"
              className="w-full inline-flex items-center justify-center bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-sm py-2.5 rounded-xl transition-all cursor-pointer shadow"
            >
              Verifikasi Akses
            </button>
          </form>
        </div>
      ) : (
        /* Authenticated admin content layout */
        <div className="grid grid-cols-1 md:grid-cols-12 min-h-[480px]">
          {/* Side tabs menu */}
          <div className="md:col-span-3 bg-gray-50 border-r border-gray-200 p-4 space-y-2">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-3 mb-2">Menu Kelayakan</p>
            {[
              { key: 'config', label: 'Setelan Portal', icon: Settings },
              { key: 'subjects', label: 'Setelan Mapel', icon: BookOpen },
              { key: 'students', label: 'Database Siswa', icon: Users },
              { key: 'mading', label: 'Moderasi Mading', icon: MessageSquare }
            ].map((tab) => {
              const Icon = tab.icon;
              const isSel = adminTab === tab.key;
              return (
                <button
                  id={`admin-tab-btn-${tab.key}`}
                  key={tab.key}
                  onClick={() => {
                    setAdminTab(tab.key as any);
                    setIsAddingStudent(false);
                  }}
                  className={`w-full inline-flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs md:text-sm font-semibold transition-all cursor-pointer ${
                    isSel
                      ? 'bg-emerald-850 text-white shadow'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-200/50'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Core Settings forms content space */}
          <div className="md:col-span-9 p-6">
            {/* TAB 1: SETTING PORTAL & COUNTDOWN */}
            {adminTab === 'config' && (
              <form onSubmit={handleSaveConfig} className="space-y-6">
                <div>
                  <h3 className="font-bold text-gray-900 text-base mb-1">Konfigurasi Sekolah & Pembatasan Tanggal</h3>
                  <p className="text-xs text-gray-500 font-sans">Ubah identitas kelulusan dan sinkronisasikan hitung mundur pelepasan data.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="config-school-name" className="block text-xs font-bold text-gray-700 uppercase mb-1">Nama Lembaga Sekolah</label>
                    <input
                      id="config-school-name"
                      type="text"
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="config-accreditation" className="block text-xs font-bold text-gray-700 uppercase mb-1">Akreditasi</label>
                    <input
                      id="config-accreditation"
                      type="text"
                      value={accreditation}
                      onChange={(e) => setAccreditation(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label htmlFor="config-school-address" className="block text-xs font-bold text-gray-700 uppercase mb-1">Alamat Resmi Sekolah</label>
                    <input
                      id="config-school-address"
                      type="text"
                      value={schoolAddress}
                      onChange={(e) => setSchoolAddress(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="config-academic-year" className="block text-xs font-bold text-gray-700 uppercase mb-1">Tahun Pelajaran</label>
                    <input
                      id="config-academic-year"
                      type="text"
                      value={academicYear}
                      onChange={(e) => setAcademicYear(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:border-emerald-600 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="config-announcement-date" className="block text-xs font-bold text-gray-700 uppercase mb-1">Tanggal Waktu Rilis</label>
                    <input
                      id="config-announcement-date"
                      type="datetime-local"
                      value={announcementDate}
                      onChange={(e) => setAnnouncementDate(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:border-emerald-600 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    />
                  </div>

                  <div className="sm:col-span-2 border-t border-gray-150 pt-4 mt-2">
                    <label className="block text-xs font-bold text-gray-700 uppercase mb-2">Logo Resmi Lembaga / Sekolah</label>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-gray-50 border border-gray-150 p-4 rounded-xl">
                      {/* Logo Preview Box */}
                      <div className="w-16 h-16 rounded-xl bg-white border border-gray-200 flex items-center justify-center overflow-hidden shrink-0 shadow-sm relative">
                        {schoolLogoUrl ? (
                          <img
                            src={schoolLogoUrl}
                            alt="Logo Sekolah"
                            className="w-full h-full object-contain p-1"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-full bg-emerald-50 text-emerald-800 flex items-center justify-center text-xs font-bold font-sans text-center px-1">
                            Logo Bawaan
                          </div>
                        )}
                      </div>

                      {/* Controls container */}
                      <div className="flex-1 space-y-2 w-full">
                        <div className="flex flex-wrap gap-2">
                          <label className="inline-flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer shadow-sm">
                            <Upload className="w-3.5 h-3.5" />
                            Unggah File Logo (PNG/JPEG/SVG)
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleLogoFileChange}
                              className="hidden"
                            />
                          </label>
                          {schoolLogoUrl && (
                            <button
                              type="button"
                              onClick={() => setSchoolLogoUrl('')}
                              className="inline-flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-100 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                            >
                              Sembunyikan / Reset Default
                            </button>
                          )}
                        </div>

                        <div>
                          <input
                            type="text"
                            placeholder="Atau tempelkan tautan URL gambar logo di sini..."
                            value={schoolLogoUrl}
                            onChange={(e) => setSchoolLogoUrl(e.target.value)}
                            className="w-full px-3 py-1.5 bg-white border border-gray-250 rounded-lg text-xs placeholder-gray-400 focus:border-emerald-600 focus:outline-none"
                          />
                          <p className="text-[10px] text-gray-500 mt-1 font-sans">
                            File logo maksimum 2MB. Logo custom akan ditampilkan di Beranda dan Surat Keterangan Lulus (SKL) siswa.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Preset Fast Actions */}
                <div className="bg-emerald-50/70 border border-emerald-100 p-4 rounded-xl space-y-2">
                  <p className="text-xs font-bold text-emerald-950 uppercase tracking-wide">Pintasan Setelan Waktu (Uji Pengumuman):</p>
                  <div className="flex flex-wrap gap-2">
                    <button
                      id="preset-time-30s"
                      type="button"
                      onClick={() => setPresetTime(0.5)} // 30 seconds count down
                      className="inline-flex items-center gap-1 bg-white hover:bg-emerald-110 px-3 py-1.5 border border-emerald-200 rounded-lg text-xs font-semibold text-emerald-800 transition-all cursor-pointer"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      Mulai Mundur 30 Detik
                    </button>
                    <button
                      id="preset-time-past"
                      type="button"
                      onClick={() => {
                        const past = new Date();
                        past.setDate(past.getDate() - 1);
                        setAnnouncementDate(past.toISOString().substring(0, 16));
                      }}
                      className="inline-flex items-center gap-1 bg-white hover:bg-emerald-110 px-3 py-1.5 border border-emerald-200 rounded-lg text-xs font-semibold text-emerald-800 transition-all cursor-pointer"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      Set Sudah Rilis (Kemarin)
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 border border-gray-150 rounded-xl">
                  <div className="space-y-0.5">
                    <span className="text-xs font-bold text-gray-900 block">Metode Akses Langsung</span>
                    <span className="text-[11px] text-gray-500 font-sans block">Abaikan hitung mundur, izinkan siswa mencari datanya rilis seketika.</span>
                  </div>
                  <button
                    id="toggle-direct-release-btn"
                    type="button"
                    onClick={() => setIsReleasedDirectly(!isReleasedDirectly)}
                    className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                      isReleasedDirectly
                        ? 'bg-emerald-800 text-white border-emerald-900'
                        : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {isReleasedDirectly ? 'Aktif (Direct)' : 'Nonaktif (Mundur)'}
                  </button>
                </div>

                <button
                  id="save-settings-btn"
                  type="submit"
                  className="inline-flex items-center gap-2 bg-emerald-850 hover:bg-emerald-950 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-sm transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  Simpan Konfigurasi Portal
                </button>
              </form>
            )}

            {/* TAB: ATUR MATA PELAJARAN MANUAL */}
            {adminTab === 'subjects' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-gray-900 text-base mb-1">Pengaturan Mata Pelajaran Rapor Kelulusan</h3>
                    <p className="text-xs text-gray-500 font-sans">Tambahkan, nama ulang, atau atur daftar mata pelajaran yang ditampilkan pada rincian nilai SKL.</p>
                  </div>
                  <button
                    id="reset-subjects-default-btn"
                    type="button"
                    onClick={() => {
                      if (confirm('Atur ulang seluruh mata pelajaran ke standard default MTs KH. A. Wahab Muhsin (12 Mapel)? Ini akan menimpa setelan kustom Anda.')) {
                        setSubjectsList(DEFAULT_SUBJECTS);
                        onSaveConfig({ ...config, subjects: DEFAULT_SUBJECTS });
                        alert('Berhasil diatur ulang ke 12 mata pelajaran standar!');
                      }
                    }}
                    className="inline-flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-750 font-bold text-xs px-4 py-2 rounded-xl border border-gray-250 shadow-sm transition-all cursor-pointer"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    Reset ke Standar (12 Mapel)
                  </button>
                </div>

                {/* Subject Editor and List */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Form Create/Edit Subject */}
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!newSubName.trim() || !newSubCode.trim()) {
                        alert('Mohon lengkapi Nama dan Kode Mata Pelajaran.');
                        return;
                      }

                      const updatedCode = newSubCode.trim().toUpperCase();

                      if (editingSubId) {
                        // Edit existing
                        const updated = subjectsList.map((sub) => 
                          sub.id === editingSubId ? { ...sub, name: newSubName.trim(), code: updatedCode } : sub
                        );
                        setSubjectsList(updated);
                        onSaveConfig({ ...config, subjects: updated });
                        setEditingSubId(null);
                        alert('Mata pelajaran berhasil diperbaharui!');
                      } else {
                        // Create new
                        const isExist = subjectsList.some(s => s.code === updatedCode);
                        if (isExist) {
                          alert(`Kode mapel "${updatedCode}" sudah digunakan.`);
                          return;
                        }

                        const newSub: Subject = {
                          id: `sbj-${Date.now()}`,
                          name: newSubName.trim(),
                          code: updatedCode
                        };
                        const updated = [...subjectsList, newSub];
                        setSubjectsList(updated);
                        onSaveConfig({ ...config, subjects: updated });
                        alert('Mata pelajaran baru berhasil ditambahkan!');
                      }
                      setNewSubName('');
                      setNewSubCode('');
                    }}
                    className="lg:col-span-5 bg-amber-50/30 border border-amber-200 p-5 rounded-2xl space-y-4 font-sans"
                  >
                    <h4 className="font-bold text-gray-900 text-xs uppercase tracking-wider text-emerald-950">
                      {editingSubId ? '✏️ Edit Mata Pelajaran' : '➕ Tambah Mata Pelajaran Baru'}
                    </h4>

                    <div className="space-y-1">
                      <label htmlFor="new-sub-name" className="block text-[11px] font-bold text-gray-700 uppercase">Nama Mata Pelajaran</label>
                      <input
                        id="new-sub-name"
                        type="text"
                        required
                        value={newSubName}
                        onChange={(e) => setNewSubName(e.target.value)}
                        placeholder="Contoh: Seni Budaya & Prakarya"
                        className="w-full px-3 py-2 border border-gray-250 bg-white rounded-lg text-xs focus:outline-emerald-600 font-medium"
                      />
                    </div>

                    <div className="space-y-1">
                      <label htmlFor="new-sub-code" className="block text-[11px] font-bold text-gray-700 uppercase">Kode Mapel (Singkat &Unik)</label>
                      <input
                        id="new-sub-code"
                        type="text"
                        required
                        value={newSubCode}
                        onChange={(e) => setNewSubCode(e.target.value)}
                        placeholder="Contoh: SBP"
                        className="w-full px-3 py-2 border border-gray-250 bg-white rounded-lg text-xs focus:outline-emerald-600 font-mono font-bold"
                      />
                      <p className="text-[10px] text-gray-400">Gunakan singkatan ringkas, huruf kapital (contoh: IND, MAT-W).</p>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        id="save-subject-btn"
                        type="submit"
                        className="flex-1 bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-xs py-2 rounded-xl shadow-sm transition-all"
                      >
                        {editingSubId ? 'Simpan Perubahan' : 'Masukkan Mapel'}
                      </button>
                      {editingSubId && (
                        <button
                          id="cancel-edit-subject-btn"
                          type="button"
                          onClick={() => {
                            setEditingSubId(null);
                            setNewSubName('');
                            setNewSubCode('');
                          }}
                          className="px-3 border border-gray-300 text-gray-650 rounded-xl text-xs font-semibold hover:bg-gray-100"
                        >
                          Batal
                        </button>
                      )}
                    </div>
                  </form>

                  {/* List of Subjects */}
                  <div className="lg:col-span-7 space-y-3">
                    <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">Daftar Aktif ({activeSubjects.length} Mata Pelajaran):</p>
                    <div className="border border-gray-200 rounded-2xl overflow-hidden bg-white max-h-[350px] overflow-y-auto shadow-inner">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-gray-50 text-gray-700 uppercase font-bold sticky top-0 border-b border-gray-150">
                          <tr>
                            <th className="px-4 py-2.5">Kode</th>
                            <th className="px-4 py-2.5">Nama Mata Pelajaran</th>
                            <th className="px-4 py-2.5 text-right">Tindakan</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 font-medium">
                          {activeSubjects.map((sub) => (
                            <tr key={sub.id} className="hover:bg-gray-50/50">
                              <td className="px-4 py-2.5 font-mono text-emerald-850 font-bold">{sub.code}</td>
                              <td className="px-4 py-2.5 text-gray-900 font-sans">{sub.name}</td>
                              <td className="px-4 py-2.5 text-right space-x-1.5 whitespace-nowrap">
                                <button
                                  id={`edit-sub-${sub.id}`}
                                  type="button"
                                  onClick={() => {
                                    setEditingSubId(sub.id);
                                    setNewSubName(sub.name);
                                    setNewSubCode(sub.code);
                                  }}
                                  className="text-emerald-700 hover:text-emerald-950 p-1 rounded hover:bg-emerald-50 transition-all cursor-pointer inline-flex"
                                  title="Edit"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  id={`delete-sub-${sub.id}`}
                                  type="button"
                                  onClick={() => {
                                    if (confirm(`Hapus mata pelajaran "${sub.name}"? Ini akan menghilangkan nilai mapel ini dalam cetakan SKL jika belum dikonfigurasi ulang.`)) {
                                      const updated = subjectsList.filter(s => s.id !== sub.id);
                                      setSubjectsList(updated);
                                      onSaveConfig({ ...config, subjects: updated });
                                      alert('Mata pelajaran dihapus dari konfigurasi.');
                                    }
                                  }}
                                  className="text-rose-600 hover:text-rose-900 p-1 rounded hover:bg-rose-50 transition-all cursor-pointer inline-flex"
                                  title="Hapus"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <p className="text-[10px] text-gray-400 italic">
                      *Catatan: Semua siswa yang ditambahkan setelah konfigurasi mata pelajaran ini diubah akan otomatis menggunakan struktur mapor di atas.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: MANAJEMEN SISWA DATABASE */}
            {adminTab === 'students' && (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-gray-900 text-base mb-1">Pangkalan Data (Database) Kelulusan</h3>
                    <p className="text-xs text-gray-500 font-sans">Kelola hak akses siswa akhir, edit status kelulusan, dan sesuaikan rincian nilai akhir.</p>
                  </div>
                  {!isAddingStudent && !isBulkImportOpen && (
                    <div className="flex flex-wrap gap-2 shrink-0">
                      <button
                        id="toggle-bulk-import-btn"
                        onClick={() => setIsBulkImportOpen(true)}
                        className="inline-flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-emerald-950 font-bold text-xs px-4 py-2 rounded-xl shadow-sm transition-all cursor-pointer"
                      >
                        <FileSpreadsheet className="w-4 h-4" />
                        Template & Impor Massal
                      </button>
                      <button
                        id="add-student-btn"
                        onClick={() => setIsAddingStudent(true)}
                        className="inline-flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-xs px-4 py-2 rounded-xl shadow-sm transition-all cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        Tambah Siswa Baru
                      </button>
                    </div>
                  )}
                </div>

                {isBulkImportOpen && (
                  <form onSubmit={handleBulkImport} className="bg-amber-50/40 border border-amber-200 p-6 rounded-2xl mt-4 space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-amber-250/60 font-sans">
                      <div className="flex items-center gap-2">
                        <FileSpreadsheet className="w-5 h-5 text-amber-700" />
                        <h4 className="font-extrabold text-gray-900 text-sm">Template & Pengimpor Massal Data Siswa (Excel/Spreadsheet)</h4>
                      </div>
                      <button
                        id="close-bulk-import-btn"
                        type="button"
                        onClick={() => {
                          setIsBulkImportOpen(false);
                          setBulkDataInput('');
                        }}
                        className="text-gray-405 hover:text-gray-650 transition-all cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="space-y-2 text-xs text-gray-700 leading-relaxed font-sans">
                      <p>
                        Anda dapat mengimpor data siswa sekaligus langsung dari spreadsheet (Excel/Google Sheets) tanpa mengisinya satu per satu.
                      </p>
                      
                      <div className="bg-white border border-gray-255 rounded-lg p-3 space-y-1">
                        <p className="font-extrabold text-emerald-950 uppercase tracking-wide">Urutan Kolom Template Excel Anda:</p>
                        <div className="flex flex-wrap gap-1 font-mono text-[9px] font-bold">
                          <span className="bg-slate-100 px-2 py-1 border rounded">1. NISN</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">2. No_Ujian</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">3. Nama_Lengkap</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">4. Kelas</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">5. Tempat_Lahir</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">6. Tgl_Lahir</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">7. Status</span>
                          <span className="bg-slate-100 px-2 py-1 border rounded">8. No_Surat_SKL</span>
                          {activeSubjects.map((sub, sIdx) => (
                            <span key={sub.code} className="bg-amber-50 px-2 py-1 border border-amber-300 text-amber-900 rounded shrink-0">
                              {9 + sIdx}. Nilai_{sub.code}
                            </span>
                          ))}
                        </div>
                        <p className="text-[10px] text-gray-500 mt-1 italic leading-relaxed">
                          *Tips Praktis: Pisahkan kolom di spreadsheet Anda dengan tab (cukup salin baris tabel Excel lalu tempelkan langsung di box di bawah). Nilai default 80 bila kosong.
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-2 pt-1 font-sans">
                        <button
                          id="download-template-excel-btn"
                          type="button"
                          onClick={handleDownloadTemplate}
                          className="inline-flex items-center gap-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-[10px] sm:text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer shadow-sm"
                        >
                          <Download className="w-3.5 h-3.5" />
                          Unduh Template CSV / Excel ({activeSubjects.length} Mapel)
                        </button>
                        <button
                          id="autofill-dummy-import-btn"
                          type="button"
                          onClick={() => {
                            setBulkDataInput(
                              `0012445511	U-MTSWM-2026-003	Rifqy Syabani Pratama	IX-A	Tasikmalaya	20 Maret 2011	LULUS	053/MTs.AWM/V/2026	92	88	85	95	90	91\n0012445522	U-MTSWM-2026-004	Aura Salsabila Rahmi	IX-B	Bandung	15 Mei 2011	LULUS	054/MTs.AWM/V/2026	85	90	92	88	85	86\n0012445533	U-MTSWM-2026-005	Budi Gunawan Susanto	IX-A	Tasikmalaya	05 Agustus 2010	DITUNDA	055/MTs.AWM/V/2026	70	72	68	74	75	71`
                            );
                          }}
                          className="bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 text-[10px] sm:text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer shadow-sm"
                        >
                          📋 Tempel Contoh Data Otomatis
                        </button>
                        <button
                          id="clear-bulk-input-btn"
                          type="button"
                          onClick={() => setBulkDataInput('')}
                          className="bg-white hover:bg-slate-100 border border-slate-300 text-rose-600 text-[10px] sm:text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer"
                        >
                          Kosongkan Box
                        </button>
                      </div>
                    </div>

                    <div className="space-y-1.5 pt-1">
                      <label htmlFor="bulk-data-input" className="block text-xs font-bold text-gray-800 uppercase font-sans">Tempelkan Data Excel / CSV Baru di bawah ini:</label>
                      <textarea
                        id="bulk-data-input"
                        rows={6}
                        value={bulkDataInput}
                        onChange={(e) => setBulkDataInput(e.target.value)}
                        placeholder={`Salin data di Excel Anda dan tempel di sini...\nContoh:\n0012445511\tU-MTSWM-2026-003\tAhmad Faisal\tIX-A\tTasikmalaya\t12 Juni 2011\tLULUS\t053\t85\t90\t80\t95\t88\t84`}
                        className="w-full p-3 border border-gray-350 bg-white rounded-xl text-xs font-mono focus:outline-emerald-600 shadow-inner leading-relaxed"
                      />
                    </div>

                    <div className="flex justify-end gap-3 pt-2 font-sans">
                      <button
                        id="cancel-bulk-btn"
                        type="button"
                        onClick={() => {
                          setIsBulkImportOpen(false);
                          setBulkDataInput('');
                        }}
                        className="px-4 py-2 border border-gray-250 bg-white rounded-xl text-xs font-semibold text-gray-650 hover:bg-gray-100 transition-all cursor-pointer"
                      >
                        Batal
                      </button>
                      <button
                        id="submit-bulk-btn"
                        type="submit"
                        className="px-5 py-2 bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
                      >
                        Mulai Impor Siswa ({bulkDataInput.trim() ? bulkDataInput.trim().split('\n').filter(l => l.trim()).length : 0} baris)
                      </button>
                    </div>
                  </form>
                )}

                {isAddingStudent ? (
                  /* Create or Edit Student forms */
                  <form onSubmit={handleCreateOrEditStudent} className="bg-gray-50 p-6 rounded-2xl border border-gray-200 mt-4 space-y-6">
                    <div className="flex items-center justify-between pb-3 border-b border-gray-200">
                      <h4 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-500 fill-current" />
                        {editingStudentId ? 'Ubah Informasi Siswa' : 'Buat Siswa Baru'}
                      </h4>
                      <button
                        id="cancel-student-form-btn"
                        type="button"
                        onClick={resetStudentForm}
                        className="text-gray-400 hover:text-gray-600 cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="student-name-input" className="block text-xs font-bold text-gray-700 uppercase mb-1">Nama Lengkap Siswa*</label>
                        <input
                          id="student-name-input"
                          type="text"
                          required
                          value={stdName}
                          onChange={(e) => setStdName(e.target.value)}
                          placeholder="M. Zaky Pratama"
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600"
                        />
                      </div>

                      <div>
                        <label htmlFor="student-nisn-input" className="block text-xs font-bold text-gray-700 uppercase mb-1">Nomor NISN (10 Digit)*</label>
                        <input
                          id="student-nisn-input"
                          type="text"
                          required
                          maxLength={10}
                          placeholder="0012345678"
                          value={stdNisn}
                          onChange={(e) => setStdNisn(e.target.value.replace(/\D/g, ''))} // Digit only
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600 font-mono"
                        />
                      </div>

                      <div>
                        <label htmlFor="student-exam-no-input" className="block text-xs font-bold text-gray-700 uppercase mb-1">No. Ujian Nasional*</label>
                        <input
                          id="student-exam-no-input"
                          type="text"
                          required
                          placeholder="U-MTSWM-2026-XYZ"
                          value={stdExamNo}
                          onChange={(e) => setStdExamNo(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600 font-mono"
                        />
                      </div>

                      <div>
                        <label htmlFor="student-class-select" className="block text-xs font-bold text-gray-700 uppercase mb-1">Kelas Rombel*</label>
                        <select
                          id="student-class-select"
                          value={stdClass}
                          onChange={(e) => setStdClass(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600 cursor-pointer"
                        >
                          <option value="IX-A">IX-A</option>
                          <option value="IX-B">IX-B</option>
                          <option value="IX-C">IX-C</option>
                        </select>
                      </div>

                      <div>
                        <label htmlFor="student-birthplace-input" className="block text-xs font-bold text-gray-700 uppercase mb-1">Tempat Lahir</label>
                        <input
                          id="student-birthplace-input"
                          type="text"
                          value={stdBirthPlace}
                          onChange={(e) => setStdBirthPlace(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600"
                        />
                      </div>

                      <div>
                        <label htmlFor="student-birthdate-input" className="block text-xs font-bold text-gray-700 uppercase mb-1">Tanggal Lahir</label>
                        <input
                          id="student-birthdate-input"
                          type="text"
                          value={stdBirthDate}
                          onChange={(e) => setStdBirthDate(e.target.value)}
                          placeholder="12 Juni 2008"
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600"
                        />
                      </div>

                      <div>
                        <label htmlFor="student-status-select" className="block text-xs font-bold text-gray-700 uppercase mb-1">Status Kelulusan Akhir*</label>
                        <select
                          id="student-status-select"
                          value={stdStatus}
                          onChange={(e) => setStdStatus(e.target.value as GraduationStatus)}
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600 text-emerald-950 font-bold cursor-pointer"
                        >
                          <option value="LULUS">LULUS (Memenuhi Syarat)</option>
                          <option value="DITUNDA">DITUNDA (Belum Gunting/Remedial)</option>
                        </select>
                      </div>

                      <div>
                        <label htmlFor="student-letter-no" className="block text-xs font-bold text-gray-700 uppercase mb-1">No. Surat SKL Resmi*</label>
                        <input
                          id="student-letter-no"
                          type="text"
                          required
                          value={stdLetterNo}
                          onChange={(e) => setStdLetterNo(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-sm focus:outline-emerald-600 font-mono"
                        />
                      </div>
                    </div>

                    {/* Dynamic marks config section */}
                    <div className="pt-4 border-t border-gray-250">
                      <p className="text-xs font-extrabold uppercase tracking-widest text-emerald-950 mb-3 block">Rincian Nilai Rapor Akumulatif ({activeSubjects.length} Mata Pelajaran):</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        {activeSubjects.map((sub) => (
                          <div key={sub.code}>
                            <label htmlFor={`score-input-${sub.code}`} className="text-[10px] sm:text-[11px] font-bold text-gray-500 block mb-0.5 truncate" title={sub.name}>
                              {sub.name} ({sub.code})
                            </label>
                            <input
                              id={`score-input-${sub.code}`}
                              type="number"
                              min={0}
                              max={100}
                              required
                              value={studentScores[sub.code] ?? 80}
                              onChange={(e) => {
                                const val = Math.min(100, Math.max(0, Number(e.target.value) || 0));
                                setStudentScores(prev => ({ ...prev, [sub.code]: val }));
                              }}
                              className="w-full px-2 py-1.5 border border-gray-200 rounded text-sm bg-white font-mono font-bold text-center"
                            />
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Custom physical SKL PDF Attachment Section */}
                    <div className="pt-4 border-t border-gray-250 space-y-3 font-sans">
                      <div className="space-y-0.5">
                        <p className="text-xs font-extrabold uppercase tracking-widest text-emerald-950 block">Lampiran Dokumen PDF SKL Basah (Opsional):</p>
                        <p className="text-[11px] text-gray-500 leading-relaxed font-sans">
                          Aplikasi sudah mendesain SKL digital interaktif siap print secara <strong>OTOMATIS</strong>. 
                          Namun, bila Anda sudah mendownload atau menstempel SKL fisik basah, Anda bisa menautkan atau mengupload file scan PDF nya di bawah agar siswa bisa mengunduhnya secara langsung.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Option A: Paste URL Link */}
                        <div className="space-y-1">
                          <label htmlFor="custom-pdf-url-input" className="block text-[10px] font-extrabold text-gray-650 uppercase">Tautan URL Berkas SKL (cth: Google Drive / Link Cloud)</label>
                          <input
                            id="custom-pdf-url-input"
                            type="text"
                            placeholder="https://drive.google.com/file/d/..."
                            value={stdCustomPdfUrl.startsWith('data:') ? '' : stdCustomPdfUrl}
                            onChange={(e) => {
                              setStdCustomPdfUrl(e.target.value);
                              if (e.target.value) setStdCustomPdfName('Tautan Berkas Google Drive / Cloud');
                            }}
                            className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg text-xs font-mono focus:outline-emerald-600 focus:border-emerald-650 placeholder-gray-400"
                          />
                        </div>

                        {/* Option B: Upload direct file */}
                        <div className="space-y-1">
                          <label className="block text-[10px] font-extrabold text-gray-650 uppercase">Unggah File PDF / Hasil Scan Gambar (Maks 2MB)</label>
                          <div className="relative border border-dashed border-gray-300 rounded-lg p-2.5 bg-slate-50 hover:bg-slate-100 transition-all text-center flex flex-col justify-center items-center gap-1 cursor-pointer">
                            <input
                              type="file"
                              accept=".pdf,image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  if (file.size > 2 * 1024 * 1024) {
                                    alert('Ukuran file melebihi 2MB! Mohon kompres file Anda.');
                                    return;
                                  }
                                  const reader = new FileReader();
                                  reader.onload = (event) => {
                                    const base64 = event.target?.result as string;
                                    setStdCustomPdfUrl(base64);
                                    setStdCustomPdfName(file.name);
                                    alert(`Berhasil mengimpor file: ${file.name}`);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                              className="absolute inset-0 opacity-0 cursor-pointer"
                            />
                            <div className="flex items-center gap-1.5 text-xs text-gray-600 pointer-events-none font-bold">
                              <Upload className="w-4 h-4 text-emerald-800" />
                              <span className="text-[11px] text-emerald-800 font-sans">Ambil dari Komputer / HP</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Display active status */}
                      {stdCustomPdfUrl && (
                        <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3 flex items-center justify-between text-xs font-sans">
                          <div className="flex items-center gap-2.5">
                            <FileText className="w-5 h-5 text-emerald-800 shrink-0" />
                            <div>
                              <span className="font-extrabold text-emerald-950 block">Lampiran Lampu Hijau:</span>
                              <span className="text-[10px] font-mono text-gray-500 break-all">{stdCustomPdfName || 'Berkas Terupload'}</span>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setStdCustomPdfUrl('');
                              setStdCustomPdfName('');
                            }}
                            className="text-rose-600 hover:text-rose-900 font-bold text-[11px] underline cursor-pointer"
                          >
                            Hapus Lampiran
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                      <button
                        id="discard-student-btn"
                        type="button"
                        onClick={resetStudentForm}
                        className="px-4 py-2 border border-gray-200 rounded-xl text-xs font-semibold text-gray-500 hover:bg-gray-100 transition-all cursor-pointer"
                      >
                        Batal
                      </button>
                      <button
                        id="save-student-obj-btn"
                        type="submit"
                        className="px-5 py-2 bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
                      >
                        {editingStudentId ? 'Simpan Pembaharuan' : 'Tambahkan Siswa'}
                      </button>
                    </div>
                  </form>
                ) : (
                  /* Viewing records tables lists */
                  <div className="overflow-x-auto border border-gray-150 rounded-xl">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-gray-50 text-gray-700 uppercase font-bold">
                        <tr className="border-b border-gray-150">
                          <th className="px-4 py-3">Nama Siswa</th>
                          <th className="px-4 py-3">NISN</th>
                          <th className="px-4 py-3">No. Ujian</th>
                          <th className="px-4 py-3">Kelas</th>
                          <th className="px-4 py-3 text-center">Status</th>
                          <th className="px-4 py-3 text-right">Tindakan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        {students.map((std) => (
                          <tr key={std.id} className="hover:bg-gray-50/50 transition-all font-medium">
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-gray-900 block">{std.name}</span>
                                {std.customPdfUrl && (
                                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-200 rounded shrink-0" title={`Berkas Lampiran: ${std.customPdfName || 'PDF'}`}>
                                    <FileText className="w-2.5 h-2.5" />
                                    PDF BASAH
                                  </span>
                                )}
                              </div>
                              <span className="text-[10px] text-gray-400 font-sans block">{std.birthPlace}, {std.birthDate}</span>
                            </td>
                            <td className="px-4 py-3 font-mono">{std.nisn}</td>
                            <td className="px-4 py-3 font-mono text-gray-500">{std.examNumber}</td>
                            <td className="px-4 py-3">{std.className}</td>
                            <td className="px-4 py-3 text-center">
                              <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${std.status === 'LULUS' ? 'bg-emerald-100 text-emerald-850' : 'bg-amber-100 text-amber-800'}`}>
                                {std.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button
                                id={`edit-student-${std.id}`}
                                onClick={() => handleTriggerEdit(std)}
                                className="text-emerald-800 hover:text-emerald-950 p-1 rounded hover:bg-emerald-50 transition-all mr-1.5 cursor-pointer"
                                title="Edit"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                id={`delete-student-${std.id}`}
                                onClick={() => {
                                  if (confirm(`Hapus data ${std.name} dari sistem? Tindakan ini tidak dapat dibatalkan.`)) {
                                    onDeleteStudent(std.id);
                                  }
                                }}
                                className="text-rose-600 hover:text-rose-900 p-1 rounded hover:bg-rose-50 transition-all cursor-pointer"
                                title="Hapus"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: MODERASI MADING GUESTBOOK */}
            {adminTab === 'mading' && (
              <div className="space-y-6">
                <div>
                  <h3 className="font-bold text-gray-900 text-base mb-1">Mading Digital Moderation Hub</h3>
                  <p className="text-xs text-gray-500 font-sans">Moderasi isi papan tulis ucapan selamat wisuda dari siswa demi memastikan kenyamanan.</p>
                </div>

                {messages.length === 0 ? (
                  <div className="bg-gray-50 p-12 text-center text-gray-400 rounded-xl">
                    <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    Belum ada ucapan siswa yang dikirimkan.
                  </div>
                ) : (
                  <div className="divide-y divide-gray-150 border border-gray-150 rounded-xl overflow-hidden">
                    {messages.map((msg) => (
                      <div key={msg.id} className="p-4 bg-white hover:bg-gray-50/50 transition-all flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-gray-900 text-sm">{msg.senderName}</span>
                            <span className="text-[10px] font-bold text-emerald-850 bg-emerald-50 px-2 py-0.5 rounded">
                              {msg.senderClass}
                            </span>
                            <span className="text-[10px] text-gray-400 font-mono">
                              {new Date(msg.timestamp).toLocaleString('id-ID')}
                            </span>
                          </div>
                          <p className="text-xs text-gray-600 leading-relaxed italic font-sans">
                            "{msg.message}"
                          </p>
                          <p className="text-[10px] font-bold text-rose-500">
                            ♥ Disukai: {msg.likes} Siswa
                          </p>
                        </div>

                        <button
                          id={`delete-wish-${msg.id}`}
                          onClick={() => {
                            if (confirm('Hapus ucapan ini secara permanen dari Mading?')) {
                              onDeleteMessage(msg.id);
                            }
                          }}
                          className="bg-rose-50 text-rose-600 hover:bg-rose-100 hover:text-rose-900 p-2 rounded-lg transition-all shrink-0 cursor-pointer"
                          title="Hapus"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
