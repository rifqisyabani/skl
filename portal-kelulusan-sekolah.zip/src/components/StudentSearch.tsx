import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Award, HelpCircle, ArrowRight, ShieldAlert, Sparkles, BookOpen } from 'lucide-react';
import { Student } from '../types';

interface StudentSearchProps {
  students: Student[];
  onSelectStudent: (student: Student) => void;
  countdownReleased: boolean;
}

export const StudentSearch: React.FC<StudentSearchProps> = ({
  students,
  onSelectStudent,
  countdownReleased
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [searchResult, setSearchResult] = useState<Student | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setHasSearched(false);
    setSearchResult(null);

    const query = searchQuery.trim().toLowerCase();
    if (!query) {
      setErrorMsg('Masukkan NISN, Nomor Ujian, atau Nama Lengkap Anda.');
      return;
    }

    // Search matches either:
    // nisn matches exactly
    // examNumber matches case-insensitively
    // name contains the query string
    const found = students.find(
      (s) =>
        s.nisn === query ||
        s.examNumber.toLowerCase() === query ||
        s.name.toLowerCase().includes(query)
    );

    if (found) {
      setSearchResult(found);
      setHasSearched(true);
    } else {
      setHasSearched(true);
      setSearchResult(null);
    }
  };

  // Helper template students to click for easy evaluation
  const demoStudents = [
    { label: 'Siswa Lulus (IX-A)', query: '1234567890', desc: 'M. Reyhan IX-A' },
    { label: 'Siswa Lulus (IX-B)', query: '0987654321', desc: 'Siti Rahma IX-B' },
    { label: 'Siswa Ditunda Kelulusan', query: '1122334455', desc: 'Budi Hartono IX-A' },
  ];

  return (
    <div id="student-search-section" className="w-full max-w-3xl mx-auto space-y-6">
      {/* Search Input Box */}
      <div className="bg-white border border-slate-200 rounded-3xl shadow-sm p-6 md:p-8 hover:shadow-md transition-all duration-300">
        <h3 className="text-lg md:text-xl font-display font-bold text-slate-900 mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-emerald-800" />
          Pencarian Data Kelulusan Siswa
        </h3>

        {!countdownReleased ? (
          <div className="bg-slate-50 border border-slate-200/60 rounded-2xl p-6 text-center text-slate-500 space-y-2">
            <ShieldAlert className="w-8 h-8 text-amber-500 mx-auto" />
            <p className="font-display font-semibold text-slate-700">Pencarian Belum Dibuka</p>
            <p className="text-xs max-w-sm mx-auto">
              Silakan tunggu waktu hitung mundur selesai atau hubungi Administrator Sekolah untuk jadwal rilis resmi.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <label htmlFor="student-search-input" className="sr-only">Cari NISN, Nomor Ujian, atau Nama</label>
              <input
                id="student-search-input"
                type="text"
                placeholder="Masukkan 10 digit NISN / No. Ujian / Nama Lengkap..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-28 py-3.5 md:py-4 bg-slate-50 border border-slate-200 focus:border-slate-800 focus:bg-white rounded-2xl focus:outline-none transition-all font-sans font-medium text-slate-800 placeholder:text-slate-400 text-sm md:text-base shadow-inner"
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-450 w-5 h-5" />
              <button
                id="submit-search-btn"
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-slate-900 hover:bg-slate-950 text-white font-sans font-bold text-xs md:text-sm px-4 md:px-5 py-2 md:py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
              >
                Cari Data
              </button>
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-600 font-semibold pl-1 font-mono">
                ⚠ {errorMsg}
              </p>
            )}

            {/* Quick Demo Assistors */}
            <div className="pt-2">
              <p className="text-[10px] font-sans font-extrabold text-slate-400 uppercase tracking-widest mb-3">
                Pintasan Simulasi Pencarian:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {demoStudents.map((demo) => (
                  <button
                    id={`demo-btn-${demo.query}`}
                    key={demo.query}
                    type="button"
                    onClick={() => {
                      setSearchQuery(demo.query);
                      const s = students.find((x) => x.nisn === demo.query);
                      if (s) {
                        setSearchResult(s);
                        setHasSearched(true);
                        setErrorMsg('');
                      }
                    }}
                    className="inline-flex flex-col items-start px-4 py-3 bg-slate-50 hover:bg-slate-100/80 border border-slate-200/60 rounded-2xl text-left transition-all group cursor-pointer"
                  >
                    <span className="text-[10px] font-sans font-extrabold text-emerald-800 uppercase tracking-wider">
                      {demo.label}
                    </span>
                    <span className="text-xs font-mono text-slate-900 flex items-center justify-between w-full mt-1">
                      <span>{demo.query}</span>
                      <span className="text-slate-400 font-sans text-[10.5px]">({demo.desc})</span>
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </form>
        )}
      </div>

      {/* Search Output Section */}
      <AnimatePresence mode="wait">
        {hasSearched && (
          <motion.div
            key={searchResult ? searchResult.id : 'no-result'}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="w-full"
          >
            {searchResult ? (
              searchResult.status === 'LULUS' ? (
                // PASSING SCREEN CARD (Bento Accent)
                <div id="grad-card-lulus" className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-950 text-white border-2 border-amber-400 rounded-3xl shadow-sm overflow-hidden relative hover:shadow-md transition-all duration-300">
                  {/* Decorative confetti backdrop effect in CSS */}
                  <div className="absolute inset-0 opacity-15 overflow-hidden">
                    <div className="absolute top-4 left-6 animate-bounce text-xl">🎉</div>
                    <div className="absolute top-12 right-12 animate-pulse text-2xl">✨</div>
                    <div className="absolute bottom-6 left-1/4 animate-bounce text-xl">🎓</div>
                    <div className="absolute bottom-12 right-6 animate-pulse text-xl">🌟</div>
                  </div>

                  <div className="p-6 md:p-8 relative z-10">
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
                      <div className="space-y-1.5">
                        <span className="inline-flex items-center gap-1.5 bg-amber-400 text-emerald-950 text-[10px] font-sans font-extrabold px-3 py-1 rounded-full uppercase tracking-wider leading-none shadow-sm">
                          <Sparkles className="w-3.5 h-3.5 fill-current" />
                          Selamat! Anda Dinyatakan Lulus
                        </span>
                        <h4 className="text-2xl md:text-3.5xl font-display font-extrabold tracking-tight pt-1">
                          {searchResult.name}
                        </h4>
                        <p className="text-emerald-200/95 font-mono text-xs tracking-wider">
                          NISN: {searchResult.nisn} &bull; No. Ujian: {searchResult.examNumber}
                        </p>
                      </div>
                      <div className="bg-emerald-800/60 border border-emerald-700/50 px-4 py-2.5 rounded-2xl text-center shrink-0 min-w-[110px]">
                        <p className="text-[10px] uppercase font-sans font-extrabold tracking-widest text-emerald-300">Kelas</p>
                        <p className="text-lg font-display font-black mt-0.5">{searchResult.className}</p>
                      </div>
                    </div>

                    <p className="text-xs md:text-sm text-emerald-100/90 leading-relaxed mb-6 font-sans">
                      Berdasarkan keputusan rapat pleno dewan pendidik MTs KH. A. Wahab Muhsin mengenai syarat kelulusan tahun ajaran 2025/2026, Anda dinyatakan memenuhi seluruh kriteria akademik maupun administratif dan berhak atas kelulusan ini.
                    </p>

                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-5 border-t border-emerald-800/60 mt-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-amber-400 text-emerald-950 rounded-2xl flex items-center justify-center shrink-0 shadow-md">
                          <Award className="w-5 h-5 font-bold" />
                        </div>
                        <div>
                          <p className="text-xs font-sans font-extrabold text-amber-400">Prestasi Akademik</p>
                          <p className="text-[11px] text-emerald-200/80 font-sans">Surat Keterangan Lulus digital siap dicetuskan</p>
                        </div>
                      </div>

                      <button
                        id="open-dashboard-btn"
                        onClick={() => onSelectStudent(searchResult)}
                        className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-emerald-950 font-sans font-bold px-6 py-3.5 rounded-2xl shadow-lg transition-all hover:scale-[1.02] cursor-pointer text-xs md:text-sm"
                      >
                        Buka Dashboard & SKL Anda
                        <ArrowRight className="w-4 h-4 text-emerald-950" />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                // PENDING SCREEN CARD (Bento Neutral Red)
                <div id="grad-card-ditunda" className="bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden hover:shadow-md transition-all duration-300">
                  <div className="bg-amber-500 text-white px-6 py-5 flex items-center gap-3">
                    <ShieldAlert className="w-6 h-6 shrink-0 text-white" />
                    <div>
                      <h4 className="font-display font-semibold text-base">Status Pengumuman: Kelulusan Ditunda</h4>
                      <p className="text-xs text-white/90 font-mono">NISN: {searchResult.nisn}</p>
                    </div>
                  </div>

                  <div className="p-6 md:p-8 space-y-4">
                    <div className="space-y-1">
                      <p className="text-[10px] font-sans font-extrabold text-slate-400 uppercase tracking-widest">Identitas Siswa</p>
                      <p className="text-xl font-display font-bold text-slate-900">{searchResult.name}</p>
                      <p className="text-xs font-mono text-slate-500">Kelas: {searchResult.className} &bull; No. Ujian: {searchResult.examNumber}</p>
                    </div>

                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs md:text-sm text-amber-900 leading-relaxed space-y-2">
                      <p className="font-bold">📋 Catatan Penting:</p>
                      <p className="text-amber-800 leading-relaxed font-sans text-xs">
                        Berdasarkan hasil rekapitulasi penilaian dan rapat koordinasi kelulusan sekolah, berkas akademik atau nilai ujian Anda belum memenuhi nilai batas minimal (KKM) mata pelajaran peminatan utama atau Anda memiliki kelengkapan administratif sekolah yang belum terselesaikan.
                      </p>
                      <p className="text-amber-800 font-semibold leading-relaxed font-sans text-xs">
                        Mohon segera menghadap Wali Kelas atau Koordinator Bimbingan Konseling (BK) di sekolah untuk informasi penyelesaian remidial / kelengkapan administrasi sebelum tanggal 5 Juni 2026.
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-100">
                      <p className="text-xs text-slate-500 font-sans">
                        Hubungi Layanan BK: <span className="font-bold font-mono text-slate-700">0812-3456-7890</span> (Ibu Endang)
                      </p>
                      <button
                        id="open-dashboard-ditunda-btn"
                        onClick={() => onSelectStudent(searchResult)}
                        className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans font-bold px-5 py-3 rounded-xl transition-all cursor-pointer text-xs"
                      >
                        Buka Dashboard Nilai Rinci
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              )
            ) : (
              // NOT FOUND SCREEN CARD (Bento Neutral Notice)
              <div id="grad-card-notfound" className="bg-white border border-slate-200 rounded-3xl shadow-sm p-6 md:p-8 text-center space-y-4 hover:shadow-md transition-all duration-300">
                <div className="w-12 h-12 bg-slate-50 text-slate-500 rounded-2xl flex items-center justify-center mx-auto shadow-sm border border-slate-150/40">
                  <HelpCircle className="w-6 h-6 text-slate-600" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-base font-display font-bold text-slate-900">Data Siswa Tidak Ditemukan</h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                    Kami tidak dapat menemukan siswa dengan kata kunci <span className="font-mono font-bold text-rose-600">"{searchQuery}"</span>. Mohon pastikan NISN (10 digit) atau ejaan nama yang dimasukkan sudah benar.
                  </p>
                </div>
                <div className="text-xs bg-slate-50 text-slate-600 border border-slate-150/50 p-4 rounded-2xl max-w-md mx-auto leading-relaxed">
                  <p className="font-bold mb-0.5 text-slate-800">Kesulitan Mencari Data?</p>
                  <p className="text-slate-500">
                    Silakan gunakan menu simulasi pintasan di atas untuk mengetes kartu hasil Lulus atau Ditunda, atau hubungi pusat bantuan admin sekolah.
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
