import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  FileText,
  BarChart4,
  MapPin,
  Calendar,
  Printer,
  ChevronLeft,
  Award,
  BookOpen,
  QrCode,
  Sparkles,
  Download,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { Student, SchoolConfig, GuestbookMessage } from '../types';
import { calculateAverageScore } from '../utils';
import { SchoolWall } from './SchoolWall';

interface StudentDashboardProps {
  student: Student;
  config: SchoolConfig;
  onBack: () => void;
  guestbookMessages: GuestbookMessage[];
  onAddGuestbookMessage: (senderName: string, senderClass: string, message: string, avatarColor: string) => void;
  onLikeGuestbookMessage: (id: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  student,
  config,
  onBack,
  guestbookMessages,
  onAddGuestbookMessage,
  onLikeGuestbookMessage
}) => {
  const [activeTab, setActiveTab] = useState<'skl' | 'nilai' | 'mading'>('skl');
  const averageScore = calculateAverageScore(student);

  // Determine honor level based on average score
  const getHonorLevel = (avg: number) => {
    if (avg >= 90) return { label: 'Dengan Pujian (Cum Laude)', color: 'text-amber-600 bg-amber-50 border-amber-200' };
    if (avg >= 80) return { label: 'Sangat Memuaskan', color: 'text-emerald-700 bg-emerald-50 border-emerald-250' };
    return { label: 'Memuaskan', color: 'text-blue-700 bg-blue-50 border-blue-200' };
  };

  const honor = getHonorLevel(averageScore);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="student-dashboard" className="w-full max-w-6xl mx-auto space-y-6">
      {/* Printable Area Instruction & Back controller */}
      <div className="flex items-center justify-between gap-4 print:hidden">
        <button
          id="back-to-portal-btn"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-800 hover:text-emerald-950 transition-all cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          Kembali ke Portal Pencarian
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500 hidden sm:inline">Pencarian untuk: <b>{student.name}</b></span>
          <span className={`text-[10px] uppercase font-bold px-3 py-1 rounded-full ${student.status === 'LULUS' ? 'bg-emerald-100 text-emerald-850' : 'bg-amber-100 text-amber-800'}`}>
            {student.status}
          </span>
        </div>
      </div>

      {/* Bento Grid Header Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 print:hidden">
        {/* Card 1: Student Profile Bento Info (Col Span 2) */}
        <div className="lg:col-span-2 bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900 border border-emerald-800/80 text-white rounded-3xl shadow-sm p-6 md:p-8 relative overflow-hidden flex flex-col justify-between group hover:shadow-md transition-all duration-300">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
          <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left h-full justify-between">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="w-16 h-16 rounded-2xl bg-amber-405 text-emerald-950 flex items-center justify-center font-display font-extrabold text-3xl shadow-md border-2 border-white/20 shrink-0 transform group-hover:scale-105 transition-transform duration-300">
                {student.name.charAt(0)}
              </div>
              <div className="space-y-1.5 pb-2">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <h2 className="text-xl md:text-2xl font-display font-bold tracking-tight">
                    {student.name}
                  </h2>
                  {student.status === 'LULUS' && (
                    <span className="inline-flex items-center gap-1 bg-amber-400 text-emerald-950 text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase leading-none shadow-sm">
                      <Sparkles className="w-3 h-3 fill-current animate-pulse" />
                      LULUS
                    </span>
                  )}
                </div>
                <p className="text-xs text-emerald-100/80 font-mono tracking-wider">
                  No. Ujian: {student.examNumber}
                </p>
                <p className="text-xs text-emerald-100/80 font-mono tracking-wider">
                  NISN: {student.nisn}
                </p>
              </div>
            </div>
            
            <div className="flex justify-center sm:justify-start gap-2 self-center sm:self-start">
              <span className="text-[10px] font-sans font-extrabold uppercase tracking-wider bg-emerald-800/80 border border-emerald-700/60 text-emerald-100 px-3 py-1 rounded-full">
                Kelas {student.className}
              </span>
              <span className="text-[10px] font-sans font-extrabold uppercase tracking-wider bg-amber-400 border border-amber-300 text-emerald-950 px-3 py-1 rounded-full shadow-sm">
                TP {config.academicYear}
              </span>
            </div>
          </div>
          
          <div className="relative z-10 pt-4 border-t border-emerald-800/50 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-emerald-200 mt-4">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></span>
              <span>Identitas digital tervalidasi resmi sekolah</span>
            </div>
            <span className="font-mono text-[11px] text-amber-300">Akreditasi: {config.accreditation}</span>
          </div>
        </div>

        {/* Card 2: Average Score Circular Progress Bento Card (Col Span 1) */}
        <div className="bg-white border border-slate-200 rounded-3xl shadow-sm p-6 flex flex-col justify-between items-center text-center relative overflow-hidden group hover:shadow-md transition-all duration-300">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-100 rounded-full blur-3xl opacity-30 -mr-16 -mt-16"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-emerald-100 rounded-full blur-3xl opacity-30 -ml-16 -mb-16"></div>
          
          <div className="relative z-10 w-full flex items-center justify-between border-b border-slate-100 pb-3 mb-2">
            <span className="text-xs font-sans font-extrabold text-slate-400 uppercase tracking-widest">Rata-rata Kelulusan</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-800">
              <Award className="w-4 h-4 text-emerald-700" />
            </div>
          </div>
          
          <div className="relative z-10 flex items-center justify-center my-2">
            <div className="relative w-28 h-28 rounded-full border-4 border-slate-100 flex flex-col items-center justify-center shadow-inner pt-1">
              <div className="absolute inset-1.5 border border-dashed border-slate-200 rounded-full"></div>
              <p className="text-4xl font-display font-black text-slate-900 tracking-tight leading-none font-mono">
                {averageScore}
              </p>
              <p className="text-[10px] text-slate-400 font-sans font-bold uppercase tracking-wider mt-1.5">SKALA 100</p>
            </div>
          </div>

          <div className="relative z-10 w-full pt-3 border-t border-slate-100 mt-2">
            <span className={`text-[10px] inline-flex items-center gap-1.5 font-bold px-3 py-1 rounded-full ${student.status === 'LULUS' ? 'bg-emerald-50 text-emerald-800 border border-emerald-250' : 'bg-amber-50 text-amber-800 border border-amber-200/50'}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${student.status === 'LULUS' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`}></span>
              Status: {student.status}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs Menu controllers */}
      <div className="flex bg-slate-100/80 p-1.5 rounded-2xl border border-slate-200/60 gap-1.5 print:hidden">
        {[
          { key: 'skl', label: 'Surat Keterangan Lulus (SKL)', icon: FileText },
          { key: 'nilai', label: 'Rapor & Transkrip Nilai', icon: BarChart4 },
          { key: 'mading', label: 'Mading Pengumuman & Ucapan', icon: BookOpen }
        ].map((tab) => {
          const IconComponent = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              id={`tab-btn-${tab.key}`}
              key={tab.key}
              onClick={() => setActiveTab(tab.key as any)}
              className={`flex-1 inline-flex items-center justify-center gap-2 px-3 py-3 rounded-xl text-xs md:text-sm font-display font-semibold transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-905 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
              }`}
            >
              <IconComponent className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">{tab.label}</span>
              <span className="sm:hidden">{tab.label.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Main Panel Content Area */}
      <div className="min-h-[400px]">
        {/* TAB 1: SURAT KETERANGAN LULUS */}
        {activeTab === 'skl' && (
          <div className="space-y-6">
            {/* Top download guidelines */}
            <div className="bg-white border border-gray-200 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm print:hidden">
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-gray-900">Surat Keterangan Lulus (SKL) Resmi MTs KH. A. Wahab Muhsin</h4>
                <p className="text-xs text-gray-500 max-w-xl font-sans leading-relaxed">
                  Siswa dapat menyimpan SKL interaktif ini sebagai PDF, mencetaknya secara mandiri ke kertas A4, atau langsung mendownload scan dokumen basah yang diunggah oleh pihak madrasah jika tersedia.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {student.customPdfUrl && (
                  <a
                    id="download-custom-skl-pdf-btn"
                    href={student.customPdfUrl}
                    download={student.customPdfName || `SKL_${student.name.replace(/\s+/g, '_')}_Asli.pdf`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-emerald-950 font-bold text-xs px-4 py-2 rounded-lg transition-all shadow-sm cursor-pointer border border-amber-300"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Unduh PDF Asli (Tandatangan Basah)
                  </a>
                )}
                <button
                  id="print-skl-btn"
                  onClick={handlePrint}
                  className="inline-flex items-center justify-center gap-1.5 bg-emerald-850 hover:bg-emerald-950 text-white font-bold text-xs px-4 py-2 rounded-lg transition-all shadow-sm cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Cetak SKL (PDF/Kertas)
                </button>
              </div>
            </div>

            {/* HIGH FIDELITY MOCK SKL FOR PRINTING */}
            <div
              id="printable-skl-letter"
              className="bg-white border-2 border-gray-300 rounded-lg p-8 md:p-12 shadow-md max-w-4xl mx-auto font-serif text-gray-900 leading-normal relative print:border-0 print:shadow-none print:p-0"
              style={{ minHeight: '297mm' }} // Approxinately A4 height scale
            >
              {/* Kop Surat (Letterhead header block) */}
              <div className="flex items-center gap-4 border-b-4 border-double border-gray-950 pb-4 mb-6 text-center">
                {/* Garuda/School Mock Shield logo */}
                <div className="w-16 h-16 shrink-0 border border-gray-950 flex items-center justify-center relative rounded-full print:border-black bg-white overflow-hidden">
                  {config.schoolLogoUrl ? (
                    <img
                      src={config.schoolLogoUrl}
                      alt={config.schoolName}
                      className="w-full h-full object-contain p-1"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center relative bg-emerald-50">
                      <Award className="w-10 h-10 text-emerald-900" />
                      <div className="absolute inset-1 border border-dashed border-emerald-800 rounded-full"></div>
                    </div>
                  )}
                </div>

                <div className="flex-1 space-y-1">
                  <p className="font-sans font-bold text-xs uppercase tracking-widest text-emerald-900">Kementerian Agama Republik Indonesia</p>
                  <p className="font-sans font-extrabold text-base md:text-lg uppercase text-gray-950">Kantor Kementerian Agama Kabupaten Tasikmalaya</p>
                  <h1 className="font-sans font-black text-lg md:text-xl uppercase tracking-tight text-gray-955 leading-tight">
                    {config.schoolName}
                  </h1>
                  <p className="font-sans text-[10px] md:text-xs text-gray-650 italic leading-none">
                    {config.schoolAddress}
                  </p>
                  <p className="font-sans text-[9px] md:text-[10px] text-gray-500 font-bold leading-none uppercase">
                    Akreditasi Sekolah: {config.accreditation} &bull; Email: info@mtsawahabmuhsin.sch.id
                  </p>
                </div>
              </div>

              {/* Document Identity Title */}
              <div className="text-center space-y-1 mb-6">
                <h3 className="font-bold text-base md:text-lg uppercase underline tracking-wider">Surat Keterangan Lulus</h3>
                <p className="font-sans text-xs font-semibold">Nomor: {student.status === 'LULUS' ? student.letterNumber : '—'}</p>
              </div>

              {/* Letter Statement Body */}
              <div className="space-y-4 text-xs md:text-sm text-justify">
                <p>
                  Yang bertanda tangan di bawah ini Kepala Madrasah Tsanawiyah KH. A. Wahab Muhsin selaku penyelenggara pendidikan di bawah naungan Kementerian Agama RI, menerangkan berdasarkan keputusan rapat pleno Dewan Guru mengenai kelulusan siswa akhir, bahwa:
                </p>

                {/* Identity Block */}
                <div className="pl-6 md:pl-10 space-y-2 py-2">
                  <table className="w-full text-left font-serif text-xs md:text-sm">
                    <tbody>
                      <tr>
                        <td className="w-1/3 py-1 font-bold">Nama Lengkap</td>
                        <td className="w-4 py-1">:</td>
                        <td className="py-1 uppercase font-sans font-bold">{student.name}</td>
                      </tr>
                      <tr>
                        <td className="py-1 font-bold">Tempat, Tanggal Lahir</td>
                        <td className="py-1">:</td>
                        <td className="py-1">{student.birthPlace}, {student.birthDate}</td>
                      </tr>
                      <tr>
                        <td className="py-1 font-bold">NISN</td>
                        <td className="py-1">:</td>
                        <td className="py-1 font-mono">{student.nisn}</td>
                      </tr>
                      <tr>
                        <td className="py-1 font-bold">Nomor Peserta Ujian</td>
                        <td className="py-1">:</td>
                        <td className="py-1 font-mono">{student.examNumber}</td>
                      </tr>
                      <tr>
                        <td className="py-1 font-bold">Program Keahlian / Kelas</td>
                        <td className="py-1">:</td>
                        <td className="py-1">{student.className}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <p className="indent-8 font-sans">
                  Dinyatakan:
                </p>

                {/* Big status box inside the official SKL */}
                <div className="text-center py-4">
                  <div className={`inline-block border-2 ${student.status === 'LULUS' ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-sans' : 'border-amber-650 bg-amber-50 text-amber-950 font-sans'} font-extrabold text-lg md:text-2xl px-12 py-3 rounded-lg shadow-sm tracking-widest`}>
                    {student.status === 'LULUS' ? 'L U L U S' : 'D I T U N D A'}
                  </div>
                </div>

                {student.status === 'LULUS' ? (
                  <p>
                    dari satuan pendidikan {config.schoolName} tahun ajaran {config.academicYear} berdasarkan kriteria kelulusan akademik dan kurikulum standar nasional yang telah dipersyaratkan oleh Kementerian Agama RI.
                  </p>
                ) : (
                  <p className="text-amber-900 border border-amber-250 bg-amber-50/50 p-4 rounded text-left font-sans text-xs">
                    <b>Ketentuan Kehadiran / Remedial:</b> Untuk menyelesaikan status kelulusan, siswa harap segera kembali mendaftarkan diri pada program remidial pemenuhan nilai akhir dan melunasi berkas registrasi kartu bebas perpustakaan sekolah pada jam kerja sekolah paling lambat 7 hari kerja sejak surat diterbitkan.
                  </p>
                )}

                <p>
                  Surat keterangan ini diberikan sebagai bukti sementara penunjang administratif sebelum ijazah asli diterbitkan secara kolektif oleh Kementerian Agama Kantor Kabupaten Tasikmalaya. Segala kekeliruan atau penyalahgunaan atas surat keterangan ini akan ditindaklanjuti sesuai prosedur perundang-undangan yang berlaku.
                </p>
              </div>

              {/* Subject scores preview inside SKL */}
              {student.status === 'LULUS' && (
                <div className="pt-6">
                  <p className="font-bold underline text-xs uppercase mb-2">Lampiran Rekapitulasi Penilaian Satuan Pendidikan:</p>
                  <table className="w-full border-collapse border border-gray-901 text-[10px] md:text-xs">
                    <thead>
                      <tr className="bg-gray-50 text-center uppercase">
                        <th className="border border-gray-901 p-1">No</th>
                        <th className="border border-gray-901 p-1 text-left">Mata Pelajaran</th>
                        <th className="border border-gray-901 p-1 w-24">Nilai Akhir Rata-rata</th>
                      </tr>
                    </thead>
                    <tbody>
                      {student.scores.map((score, idx) => (
                        <tr key={score.code}>
                          <td className="border border-gray-901 text-center p-1">{idx + 1}</td>
                          <td className="border border-gray-901 p-1 font-sans text-[11px] font-medium">{score.subject}</td>
                          <td className="border border-gray-901 font-mono text-center font-bold p-1">{score.score}</td>
                        </tr>
                      ))}
                      <tr className="bg-gray-50 font-bold">
                        <td colSpan={2} className="border border-gray-901 text-right p-1 uppercase">Rataan Akhir Nilai Kelulusan</td>
                        <td className="border border-gray-901 font-mono text-center text-emerald-850 p-1">{averageScore}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              {/* Signatures & Seal section */}
              <div className="pt-8 grid grid-cols-2 gap-4 items-end text-xs">
                {/* QR Code Validation */}
                <div className="flex flex-col items-center sm:items-start text-center sm:text-left space-y-1">
                  <div className="p-1.5 border border-gray-200 rounded-md bg-white w-24 h-24 flex items-center justify-center">
                    {/* Simulated QR Code using SVG structure */}
                    <div className="w-20 h-20 bg-gray-50 flex flex-col items-center justify-center text-gray-800 relative">
                      <QrCode className="w-16 h-16 opacity-80" />
                      <span className="absolute bottom-0 inset-x-0 bg-emerald-900 text-white font-sans font-bold text-[6px] text-center uppercase leading-none py-0.5">
                        VERIFIED
                      </span>
                    </div>
                  </div>
                  <p className="font-sans text-[9px] text-gray-500 font-bold max-w-[150px]">
                    Scan QR ini untuk memverifikasi keabsahan dokumen SKL secara digital di portal sekolah.
                  </p>
                </div>

                {/* Principal Signature Details with Blue stamp effect */}
                <div className="text-right space-y-1 flex flex-col items-end">
                  <p className="font-sans text-xs font-semibold">Tasikmalaya, 29 Mei 2026</p>
                  <p className="font-sans text-xs font-bold uppercase">Kepala Madrasah {config.schoolName}</p>

                  {/* Stamp Graphic & Signature Simulated placeholder */}
                  <div className="h-20 w-44 relative my-1 flex items-center justify-end">
                    {/* Mock Stamp circle overlay */}
                    <div className="absolute right-12 top-2 w-20 h-20 rounded-full border-2 border-double border-blue-600/30 flex items-center justify-center pointer-events-none rotate-12">
                      <div className="text-[7px] text-blue-600/40 text-center font-sans font-bold uppercase leading-tight select-none">
                        MTs KH.AWM<br />
                        TASIKMALAYA<br />
                        KEMENAG RI
                      </div>
                    </div>

                    {/* Blue ink signature mock path */}
                    <svg className="w-28 h-12 text-blue-700 opacity-80 z-10" viewBox="0 0 100 40">
                      <path
                        d="M10,25 C30,10 40,5 50,22 C60,40 70,30 90,15"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                      />
                      <path
                        d="M20,15 C45,18 55,10 75,28"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                      />
                    </svg>

                    {/* Official stamp sticker indicator */}
                    <div className="absolute bottom-2 right-1 text-[8px] font-sans text-blue-600 font-bold uppercase select-none opacity-80 tracking-wide">
                      ✔ CAP BASAH DIGITAL
                    </div>
                  </div>

                  <p className="font-bold underline text-xs font-sans uppercase text-gray-900">{student.principalName}</p>
                  <p className="font-sans text-[10px] text-gray-500 font-bold">NIP. {student.principalNip}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: DETAIL NILAI & VISUALISASI CHATS */}
        {activeTab === 'nilai' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Score stats cards & detailed breakdown list (Bento Card A) */}
              <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl shadow-sm p-6 md:p-8 space-y-6 hover:shadow-md transition-all duration-300">
                <div>
                  <h3 className="text-lg font-display font-bold text-slate-900 flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-emerald-800" />
                    Transkrip Nilai Rapor Akhir Keahlian
                  </h3>
                  <p className="text-xs text-slate-500 font-sans">
                    Rekapitulasi penilaian akhir hasil belajar yang dipertimbangkan dewan pengajar untuk kelulusan.
                  </p>
                </div>

                <div className="overflow-x-auto rounded-2xl border border-slate-100">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-700 uppercase text-xs font-display font-semibold">
                      <tr>
                        <th className="px-4 py-3.5">Kode</th>
                        <th className="px-4 py-3.5">Mata Pelajaran</th>
                        <th className="px-4 py-3.5 text-center w-32">Nilai Kelulusan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {student.scores.map((score) => {
                        const isExcellent = score.score >= 85;
                        const isUnderKkm = score.score < 75;
                        const scoreColor = isExcellent ? 'text-emerald-700 font-extrabold' : isUnderKkm ? 'text-rose-600 font-bold' : 'text-slate-800';
                        const scoreBg = isExcellent ? 'bg-emerald-50/50 text-emerald-800 border-emerald-100' : isUnderKkm ? 'bg-rose-55 border-rose-100' : 'bg-slate-50 text-slate-800 border-slate-100';
                        return (
                          <tr key={score.code} className="hover:bg-slate-50/40 transition-all font-medium">
                            <td className="px-4 py-3 font-mono text-xs text-slate-400">{score.code}</td>
                            <td className="px-4 py-3 text-slate-800 font-sans">{score.subject}</td>
                            <td className="px-4 py-3 text-center">
                              <span className={`font-mono text-sm ${scoreColor} inline-block ${scoreBg} px-3 py-1 rounded-xl border`}>
                                {score.score}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Right graphical stats & custom visualization */}
              <div className="lg:col-span-4 space-y-6">
                {/* Honors accolade banner (Bento Card B) */}
                <div className={`border p-6 rounded-3xl shadow-sm text-center space-y-3 hover:shadow-md transition-all duration-300 ${honor.color === 'text-amber-600 bg-amber-50 border-amber-200' ? 'bg-gradient-to-br from-amber-50 to-orange-50/40 border-amber-200 text-amber-900' : honor.color === 'text-emerald-700 bg-emerald-50 border-emerald-250' ? 'bg-gradient-to-br from-emerald-50 to-teal-50/40 border-emerald-200 text-emerald-900' : 'bg-gradient-to-br from-blue-50 to-indigo-50/40 border-blue-200 text-blue-900'}`}>
                  <Award className="w-10 h-10 mx-auto animate-bounce text-amber-500 fill-current" />
                  <div className="space-y-1">
                    <p className="text-[10px] font-sans font-extrabold uppercase tracking-widest text-slate-500">Index Kehormatan</p>
                    <p className="text-lg font-display font-bold leading-tight">{honor.label}</p>
                  </div>
                  <p className="text-xs px-2 text-slate-500 leading-relaxed font-sans mt-2">
                    Predikat kelulusan berdasarkan rerata kelulusan kumulatif {config.schoolName} tahun ajaran {config.academicYear}.
                  </p>
                </div>

                {/* Performance Chart Box (Bento Card C) */}
                <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4 hover:shadow-md transition-all duration-300">
                  <div>
                    <h4 className="text-sm font-display font-bold text-slate-900">Performa Visual Subjek Utama</h4>
                    <p className="text-[10.5px] text-slate-400 font-sans font-medium">Beban Enam Mata Pelajaran Utama</p>
                  </div>

                  {/* Horizontal custom bar list with animated tooltips */}
                  <div className="space-y-4 pt-2">
                    {student.scores.slice(0, 6).map((score) => {
                      const perc = score.score;
                      const barColor = score.score >= 90 ? 'bg-amber-400' : score.score >= 80 ? 'bg-emerald-600' : 'bg-rose-500';

                      return (
                        <div key={score.code} className="space-y-1.5">
                          <div className="flex items-center justify-between text-xs font-medium">
                            <span className="text-slate-700 truncate max-w-[180px] font-sans text-xs">{score.subject}</span>
                            <span className="font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg leading-none text-[10px]">
                              {score.score}/100
                            </span>
                          </div>
                          <div className="w-full bg-slate-50 rounded-full h-2 overflow-hidden border border-slate-200/40">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${perc}%` }}
                              transition={{ duration: 1, ease: 'easeOut' }}
                              className={`h-full ${barColor} rounded-full`}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="text-[10px] text-slate-500 font-sans bg-slate-50 border border-slate-100 p-3 rounded-2xl flex items-start gap-2 leading-relaxed">
                    <UserCheck className="w-4 h-4 text-emerald-800 shrink-0 mt-0.5" />
                    <p>
                      Predikat Kriteria Ketuntasan Batas Minimal (KKM) sekolah adalah <b className="font-mono text-slate-750">75.0</b>. Nilai di bawah KKM ditandai dengan warna <span className="text-rose-500 font-bold">merah</span>.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: MADING WISUDA DAN UCAPAN */}
        {activeTab === 'mading' && (
          <SchoolWall
            messages={guestbookMessages}
            onAddMessage={onAddGuestbookMessage}
            onLikeMessage={onLikeGuestbookMessage}
          />
        )}
      </div>
    </div>
  );
};
