import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Calendar, CheckCircle, Info, Lock } from 'lucide-react';
import { SchoolConfig } from '../types';
import { formatTimeRemaining } from '../utils';

interface AnnouncementCountdownProps {
  config: SchoolConfig;
  onCountdownComplete: () => void;
  onBypass: () => void;
}

export const AnnouncementCountdown: React.FC<AnnouncementCountdownProps> = ({
  config,
  onCountdownComplete,
  onBypass
}) => {
  const [timeLeft, setTimeLeft] = useState(formatTimeRemaining(config.announcementDate));

  useEffect(() => {
    // If released directly is enabled, countdown complete immediately has effect
    if (config.isReleasedDirectly) {
      onCountdownComplete();
    }

    const timer = setInterval(() => {
      const remaining = formatTimeRemaining(config.announcementDate);
      setTimeLeft(remaining);
      if (remaining.isPast) {
        onCountdownComplete();
        clearInterval(timer);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [config.announcementDate, config.isReleasedDirectly, onCountdownComplete]);

  // Format ID Date
  const formatIndonesianDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('id-ID', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        timeZoneName: 'short'
      });
    } catch {
      return dateStr;
    }
  };

  const isBypassedOrPast = config.isReleasedDirectly || timeLeft.isPast;

  return (
    <div id="announcement-countdown-card" className="w-full max-w-3xl mx-auto bg-white border border-slate-200 rounded-3xl shadow-sm overflow-hidden mb-8 hover:shadow-md transition-all duration-300">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
        {/* Bento Column 1: Elegant brand ribbon (Col Span 5) */}
        <div className="md:col-span-5 bg-gradient-to-br from-emerald-950 via-emerald-900 to-teal-900 p-6 md:p-8 text-left text-white relative flex flex-col justify-between overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]"></div>
          <div className="relative z-10 space-y-4">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] uppercase font-sans font-extrabold bg-emerald-800/80 text-emerald-100 border border-emerald-500/20 shadow-sm leading-none">
              <Lock className="w-3 h-3 text-amber-400" />
              Portal Terkunci
            </span>
            <div className="space-y-1.5">
              <h2 className="text-xl md:text-2xl font-display font-bold tracking-tight">
                Timer Pelepasan
              </h2>
              <p className="text-emerald-100/80 text-xs leading-relaxed font-sans">
                Akses kelulusan siswa akhir {config.schoolName} tahun ajaran {config.academicYear} dilepas otomatis sesuai waktu komputer server.
              </p>
            </div>
          </div>
          
          <div className="relative z-10 pt-6 mt-6 border-t border-emerald-800/40 text-[10px] text-emerald-300/80 flex items-center gap-1.5 font-mono">
            <span>● SECURE SERVER OK</span>
          </div>
        </div>

        {/* Bento Column 2: Interactive Timer and Schedules (Col Span 7) */}
        <div className="md:col-span-7 p-6 md:p-8 bg-slate-50/50 flex flex-col justify-center">
          {!isBypassedOrPast ? (
            <div className="space-y-5">
              <div className="grid grid-cols-4 gap-2.5 text-center">
                {[
                  { label: 'Hari', value: timeLeft.days, color: 'from-slate-50 to-slate-100 border-slate-200' },
                  { label: 'Jam', value: timeLeft.hours, color: 'from-slate-50 to-slate-100 border-slate-200' },
                  { label: 'Menit', value: timeLeft.minutes, color: 'from-slate-50 to-slate-100 border-slate-200' },
                  { label: 'Detik', value: timeLeft.seconds, color: 'from-slate-50 to-slate-100 border-slate-200' }
                ].map((item, idx) => (
                  <motion.div
                    key={item.label}
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: idx * 0.05 }}
                    className={`bg-gradient-to-br ${item.color} rounded-2xl p-2 md:p-3 border shadow-sm`}
                  >
                    <div className="text-2xl md:text-3.5xl font-mono font-bold text-slate-800 tracking-tight leading-none mb-1">
                      {String(item.value).padStart(2, '0')}
                    </div>
                    <div className="text-[9px] font-sans font-bold uppercase tracking-wider text-slate-450">
                      {item.label}
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="space-y-3.5">
                <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-200/60 rounded-xl p-3.5 text-xs text-amber-900 leading-relaxed">
                  <Clock className="w-4.5 h-4.5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block text-amber-950 font-sans text-xs">Jadwal Pengumuman Resmi:</span>
                    <span className="font-mono text-[11px] text-amber-800 leading-none">
                      {formatIndonesianDate(config.announcementDate)}
                    </span>
                  </div>
                </div>

                {/* Dev bypass option to make grading/evaluating easier */}
                <div className="text-center pt-2 border-t border-dashed border-slate-150">
                  <button
                    id="bypass-countdown-btn"
                    onClick={onBypass}
                    className="inline-flex items-center gap-1.5 text-xs text-emerald-800 hover:text-emerald-950 font-medium hover:underline transition-all cursor-pointer"
                  >
                    <Info className="w-3.5 h-3.5" />
                    Lewati Hitung Mundur (Evaluasi Cepat)
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center space-y-4"
            >
              <div className="w-14 h-14 bg-emerald-50 text-emerald-800 rounded-2xl flex items-center justify-center mx-auto shadow-sm border border-emerald-150/50">
                <CheckCircle className="w-7 h-7 text-emerald-700" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-display font-bold text-slate-900">
                  Gerbang Portal Telah Terbuka!
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                  Anda kini dapat memasukkan Nomor Induk Siswa Nasional (NISN) Anda di bawah untuk mengakses pengumuman kelulusan digital.
                </p>
              </div>
              <div className="inline-flex items-center gap-1.5 font-mono text-[10.5px] bg-emerald-50/50 border border-emerald-150/40 px-3 py-1.5 rounded-full text-emerald-800 font-semibold shadow-sm">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                Rilis Sejak: {formatIndonesianDate(config.announcementDate)}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};
