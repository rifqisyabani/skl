import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Send, MessageSquare, Award, Sparkles, Smile } from 'lucide-react';
import { GuestbookMessage } from '../types';

interface SchoolWallProps {
  messages: GuestbookMessage[];
  onAddMessage: (senderName: string, senderClass: string, message: string, avatarColor: string) => void;
  onLikeMessage: (id: string) => void;
}

export const SchoolWall: React.FC<SchoolWallProps> = ({
  messages,
  onAddMessage,
  onLikeMessage
}) => {
  const [name, setName] = useState('');
  const [className, setClassName] = useState('IX-A');
  const [text, setText] = useState('');
  const [selectedBg, setSelectedBg] = useState('bg-indigo-500'); // Represents Avatar badge color
  const [errorLocal, setErrorLocal] = useState('');

  const bgColors = [
    { label: 'Indigo', color: 'bg-indigo-500' },
    { label: 'Emerald', color: 'bg-emerald-500' },
    { label: 'Rose', color: 'bg-rose-500' },
    { label: 'Amber', color: 'bg-amber-500' },
    { label: 'Sky', color: 'bg-sky-500' }
  ];

  // Common junior high / MTS school classes
  const availableClasses = [
    'IX-A', 'IX-B', 'IX-C', 'Guru / Alumni', 'Orang Tua / Wali'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorLocal('');

    if (!name.trim()) {
      setErrorLocal('Mohon masukkan nama pengirim.');
      return;
    }
    if (!text.trim()) {
      setErrorLocal('Mohon masukkan ucapan selamat Anda.');
      return;
    }
    if (text.length > 300) {
      setErrorLocal('Ucapan maksimal 300 karakter.');
      return;
    }

    onAddMessage(name.trim(), className, text.trim(), selectedBg);
    setName('');
    setText('');
  };

  return (
    <div id="mading-wisuda" className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Wish Form Form */}
        <div className="lg:col-span-4 bg-white border border-emerald-100 p-6 rounded-2xl shadow-md lg:sticky lg:top-4">
          <div className="flex items-center gap-2 mb-4">
            <MessageSquare className="w-5 h-5 text-emerald-850" />
            <h3 className="font-bold text-gray-900 text-lg">Kirim Ucapan & Pesan</h3>
          </div>
          <p className="text-xs text-gray-500 mb-4 leading-relaxed font-sans">
            Tulis ungkapan syukur, terima kasih kepada guru, pesan mutiara, atau ucapan selamat wisuda untuk dibaca oleh seluruh siswa dan guru.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="wall-sender-name" className="block text-xs font-bold text-gray-700 uppercase mb-1">Nama Pengirim</label>
              <input
                id="wall-sender-name"
                type="text"
                maxLength={45}
                placeholder="cth. Andy Wijaya"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:bg-white focus:border-emerald-600 focus:outline-none transition-all font-medium text-gray-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="wall-sender-class" className="block text-xs font-bold text-gray-700 uppercase mb-1">Kelas / Jabaran</label>
                <select
                  id="wall-sender-class"
                  value={className}
                  onChange={(e) => setClassName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:bg-white focus:outline-none focus:border-emerald-600 font-medium text-gray-700 cursor-pointer"
                >
                  {availableClasses.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <span className="block text-xs font-bold text-gray-700 uppercase mb-1">Pilih Warna</span>
                <div className="flex flex-wrap items-center gap-1.5 py-1.5">
                  {bgColors.map((item) => (
                    <button
                      id={`color-badge-${item.color}`}
                      key={item.color}
                      type="button"
                      aria-label={`Pilih warna ${item.label}`}
                      onClick={() => setSelectedBg(item.color)}
                      className={`w-5 h-5 rounded-full ${item.color} border-2 ${selectedBg === item.color ? 'border-gray-905 scale-110 shadow-sm' : 'border-transparent hover:scale-105'} transition-all cursor-pointer`}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="wall-message-text" className="block text-xs font-bold text-gray-700 uppercase mb-1">Isi Pesan Wisuda ({text.length}/300)</label>
              <textarea
                id="wall-message-text"
                rows={4}
                maxLength={300}
                placeholder="Bagikan rasa syukur, memori terindah, atau harapan untuk masa depan angkatan kita..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:bg-white focus:border-emerald-600 focus:outline-none transition-all text-gray-800 font-sans"
              />
            </div>

            {errorLocal && (
              <p className="text-xs text-rose-600 font-semibold font-mono">
                ⚠ {errorLocal}
              </p>
            )}

            <button
              id="send-wish-btn"
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 bg-emerald-800 hover:bg-emerald-950 text-white font-bold text-sm py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
            >
              <Send className="w-4 h-4" />
              Kirim Ke Mading Digital
            </button>
          </form>
        </div>

        {/* Live messages wall list */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <h3 className="font-extrabold text-gray-900 text-xl tracking-tight flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-500 fill-current" />
                Mading Digital Ucapan Kelulusan
              </h3>
              <p className="text-xs text-gray-500 font-sans">
                Terdapat {messages.length} pesan hangat dari lulusan & dewan pengajar.
              </p>
            </div>
          </div>

          {messages.length === 0 ? (
            <div className="bg-gray-50 border border-gray-200 rounded-2xl p-12 text-center text-gray-500">
              <Smile className="w-10 h-10 text-emerald-800 mx-auto mb-2 opacity-50 animate-bounce" />
              <p className="font-semibold text-gray-700">Mading Masih Kosong</p>
              <p className="text-xs max-w-sm mx-auto mt-1">
                Jadilah orang pertama yang mengirimkan ucapan syukur dan apresiasi di sini!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <AnimatePresence mode="popLayout">
                {messages.map((item, idx) => (
                  <motion.div
                    key={item.id}
                    id={`mading-card-${item.id}`}
                    layout
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 260, damping: 25 }}
                    className="p-5 rounded-2xl bg-white border border-gray-150 shadow-sm flex flex-col justify-between hover:shadow-md transition-all group"
                  >
                    <div>
                      {/* Message author details */}
                      <div className="flex items-center gap-2.5 mb-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs ${item.avatarColor}`}>
                          {item.senderName ? item.senderName.charAt(0).toUpperCase() : '?'}
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-gray-900 text-sm truncate">{item.senderName}</p>
                          <span className="inline-block text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                            {item.senderClass}
                          </span>
                        </div>
                      </div>

                      {/* Msg string */}
                      <p className="text-xs text-gray-600 font-sans leading-relaxed whitespace-pre-wrap">
                        "{item.message}"
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-4 mt-4 border-t border-gray-100 text-xs text-gray-400">
                      <span className="font-mono text-[10px]">
                        {new Date(item.timestamp).toLocaleDateString('id-ID', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>

                      {/* Interactive Love Button */}
                      <button
                        id={`like-btn-${item.id}`}
                        onClick={() => onLikeMessage(item.id)}
                        className="inline-flex items-center gap-1.5 text-gray-400 hover:text-rose-600 transition-all font-semibold cursor-pointer py-1 px-2 rounded-full hover:bg-rose-50"
                      >
                        <Heart
                          className={`w-4 h-4 transition-all ${item.likes > 0 ? 'text-rose-500 fill-current' : 'text-gray-400 group-hover:scale-110'}`}
                        />
                        <span className="font-mono tracking-tight text-xs text-gray-605">
                          {item.likes}
                        </span>
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
