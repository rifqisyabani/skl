export type GraduationStatus = 'LULUS' | 'DITUNDA';

export interface StudentScore {
  subject: string;
  code: string;
  score: number;
}

export interface Student {
  id: string;
  nisn: string; // National Student Identity Number (10 digits)
  examNumber: string; // Number for identification
  name: string;
  birthPlace: string;
  birthDate: string;
  className: string;
  status: GraduationStatus;
  scores: StudentScore[];
  letterNumber: string;
  schoolName: string;
  principalName: string;
  principalNip: string;
  customPdfUrl?: string; // Pasted link or Base64 uploaded PDF data
  customPdfName?: string; // Original uploaded file name
}

export interface GuestbookMessage {
  id: string;
  senderName: string;
  senderClass: string;
  message: string;
  timestamp: string;
  likes: number;
  avatarColor: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
}

export interface SchoolConfig {
  schoolName: string;
  schoolAddress: string;
  academicYear: string;
  announcementDate: string; // ISO String or Date
  isReleasedDirectly: boolean; // Override to allow viewing immediately
  accreditation: string;
  subjects?: Subject[];
  schoolLogoUrl?: string; // Optional custom logo or Base64 uploaded value
}
