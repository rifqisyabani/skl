import { Student, GuestbookMessage, SchoolConfig } from './types';
import { INITIAL_GUESTBOOK, INITIAL_SCHOOL_CONFIG, INITIAL_STUDENTS } from './initialData';

const KEYS = {
  STUDENTS: 'siks_students_v1',
  GUESTBOOK: 'siks_guestbook_v1',
  CONFIG: 'siks_config_v1',
};

export const getSchoolConfig = (): SchoolConfig => {
  const data = localStorage.getItem(KEYS.CONFIG);
  if (!data) {
    localStorage.setItem(KEYS.CONFIG, JSON.stringify(INITIAL_SCHOOL_CONFIG));
    return INITIAL_SCHOOL_CONFIG;
  }
  try {
    return JSON.parse(data) as SchoolConfig;
  } catch {
    return INITIAL_SCHOOL_CONFIG;
  }
};

export const saveSchoolConfig = (config: SchoolConfig): void => {
  localStorage.setItem(KEYS.CONFIG, JSON.stringify(config));
};

export const getStudents = (): Student[] => {
  const data = localStorage.getItem(KEYS.STUDENTS);
  if (!data) {
    localStorage.setItem(KEYS.STUDENTS, JSON.stringify(INITIAL_STUDENTS));
    return INITIAL_STUDENTS;
  }
  try {
    return JSON.parse(data) as Student[];
  } catch {
    return INITIAL_STUDENTS;
  }
};

export const saveStudents = (students: Student[]): void => {
  localStorage.setItem(KEYS.STUDENTS, JSON.stringify(students));
};

export const getGuestbook = (): GuestbookMessage[] => {
  const data = localStorage.getItem(KEYS.GUESTBOOK);
  if (!data) {
    localStorage.setItem(KEYS.GUESTBOOK, JSON.stringify(INITIAL_GUESTBOOK));
    return INITIAL_GUESTBOOK;
  }
  try {
    return JSON.parse(data) as GuestbookMessage[];
  } catch {
    return INITIAL_GUESTBOOK;
  }
};

export const saveGuestbook = (messages: GuestbookMessage[]): void => {
  localStorage.setItem(KEYS.GUESTBOOK, JSON.stringify(messages));
};

// Compute the average score of a student
export const calculateAverageScore = (student: Student): number => {
  if (!student.scores || student.scores.length === 0) return 0;
  const sum = student.scores.reduce((acc, curr) => acc + curr.score, 0);
  return Number((sum / student.scores.length).toFixed(2));
};

// Format Date / Timers helper
export const formatTimeRemaining = (targetDateStr: string): {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isPast: boolean;
} => {
  const target = new Date(targetDateStr).getTime();
  const now = new Date().getTime();
  const diff = target - now;

  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, isPast: true };
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  return { days, hours, minutes, seconds, isPast: false };
};
