import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Lock,
  Award,
  BookOpen,
  ArrowRight,
  Bookmark,
  Sparkles,
  RefreshCw,
  HelpCircle,
  Home,
  MessageSquare
} from 'lucide-react';
import { Student, SchoolConfig, GuestbookMessage } from './types';
import {
  getSchoolConfig,
  saveSchoolConfig,
  getStudents,
  saveStudents,
  getGuestbook,
  saveGuestbook
} from './utils';
import { AnnouncementCountdown } from './components/AnnouncementCountdown';
import { StudentSearch } from './components/StudentSearch';
import { StudentDashboard } from './components/StudentDashboard';
import { AdminPanel } from './components/AdminPanel';

export default function App() {
  // Core persistent states
  const [config, setConfig] = useState<SchoolConfig>(getSchoolConfig());
  const [students, setStudents] = useState<Student[]>(getStudents());
  const [messages, setMessages] = useState<GuestbookMessage[]>(getGuestbook());

  // Interactive UI states
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [isCountdownReleased, setIsCountdownReleased] = useState(false);
  const [logoClicks, setLogoClicks] = useState(0);

  // Secret keyboard listener for toggling Admin Panel (Ctrl+Shift+A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key.toUpperCase() === 'A') {
        e.preventDefault();
        setShowAdminPanel((prev) => !prev);
        setSelectedStudent(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle discrete logo clicks (5 clicks within 3 seconds)
  const handleLogoClick = () => {
    setLogoClicks((prev) => {
      const next = prev + 1;
      if (next >= 5) {
        setShowAdminPanel((v) => !v);
        setSelectedStudent(null);
        return 0;
      }
      return next;
    });
  };

  useEffect(() => {
    if (logoClicks > 0) {
      const timer = setTimeout(() => {
        setLogoClicks(0);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [logoClicks]);

  // Monitor the actual target countdown date change
  useEffect(() => {
    // If setting says release directly is active, immediately let them search
    if (config.isReleasedDirectly) {
      setIsCountdownReleased(true);
      return;
    }

    const checkReleased = () => {
      const targetTime = new Date(config.announcementDate).getTime();
      const currentTime = new Date().getTime();
      if (currentTime >= targetTime) {
        setIsCountdownReleased(true);
      } else {
        setIsCountdownReleased(false);
      }
    };

    checkReleased();
    const interval = setInterval(checkReleased, 1000);
    return () => clearInterval(interval);
  }, [config.announcementDate, config.isReleasedDirectly]);

  // Synchronize state and local storage helpers
  const handleSaveConfig = (newConfig: SchoolConfig) => {
    setConfig(newConfig);
    saveSchoolConfig(newConfig);
  };

  const handleAddStudent = (newStudent: Student) => {
    const updated = [newStudent, ...students];
    setStudents(updated);
    saveStudents(updated);
  };

  const handleEditStudent = (editedStudent: Student) => {
    const updated = students.map((s) => (s.id === editedStudent.id ? editedStudent : s));
    setStudents(updated);
    saveStudents(updated);
    // If editing currently selected student, update active view too
    if (selectedStudent && selectedStudent.id === editedStudent.id) {
      setSelectedStudent(editedStudent);
    }
  };

  const handleDeleteStudent = (id: string) => {
    const updated = students.filter((s) => s.id !== id);
    setStudents(updated);
    saveStudents(updated);
    if (selectedStudent && selectedStudent.id === id) {
      setSelectedStudent(null);
    }
  };

  const handleAddMessage = (name: string, pClass: string, text: string, color: string) => {
    const newMsg: GuestbookMessage = {
      id: `msg-${Date.now()}`,
      senderName: name,
      senderClass: pClass,
      message: text,
      timestamp: new Date().toISOString(),
      likes: 0,
      avatarColor: color
    };
    const updated = [newMsg, ...messages];
    setMessages(updated);
    saveGuestbook(updated);
  };

  const handleLikeMessage = (id: string) => {
    const updated = messages.map((m) => {
      if (m.id === id) {
        return { ...m, likes: m.likes + 1 };
      }
      return m;
    });
    setMessages(updated);
    saveGuestbook(updated);
  };

  const handleDeleteMessage = (id: string) => {
    const updated = messages.filter((m) => m.id !== id);
    setMessages(updated);
    saveGuestbook(updated);
  };

  // Preset countdown bypass for testing ease
  const handleBypassCountdown = () => {
    const updatedConfig = { ...config, isReleasedDirectly: true };
    setConfig(updatedConfig);
    saveSchoolConfig(updatedConfig);
    setIsCountdownReleased(true);
    alert('Hitung mundur berhasil dilewati! Formulir pencarian kelulusan kini terbuka.');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans antialiased text-gray-800 transition-colors">
      
      {/* Dynamic Header navbar */}
      <header className="bg-white border-b border-gray-150 h-16 sticky top-0 z-50 print:hidden shadow-sm">
        <div className="max-w-7xl mx-auto h-full px-4 flex items-center justify-between">
          <div 
            id="secret-admin-trigger-logo"
            onClick={handleLogoClick}
            className="flex items-center gap-2.5 cursor-pointer select-none group"
          >
            {/* Elegant School Crest Badge Icon */}
            <div className="w-10 h-10 rounded-xl bg-emerald-850 flex items-center justify-center text-white font-bold relative transition-transform duration-250 group-hover:scale-102 active:scale-98 overflow-hidden bg-white border border-gray-200">
              {config.schoolLogoUrl ? (
                <img
                  src={config.schoolLogoUrl}
                  alt={config.schoolName}
                  className="w-full h-full object-contain p-1"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-emerald-850 flex items-center justify-center relative">
                  <Award className="w-5.5 h-5.5 text-amber-300" />
                  <div className="absolute inset-0.5 border border-dashed border-amber-300/40 rounded-lg"></div>
                </div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold leading-none uppercase text-emerald-800 tracking-wider">SIKS PORTAL</span>
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
              </div>
              <h1 className="text-sm md:text-base font-black text-gray-900 tracking-tight leading-none mt-0.5">
                {config.schoolName}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Home option if inside student portal */}
            {selectedStudent && (
              <button
                id="home-navigation-btn"
                onClick={() => setSelectedStudent(null)}
                className="inline-flex items-center gap-1 text-xs font-bold text-gray-650 hover:text-gray-900 px-3 py-1.5 rounded-lg hover:bg-gray-100 transition-all cursor-pointer"
              >
                <Home className="w-4 h-4" />
                <span className="hidden sm:inline">Beranda</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Core Body Layout */}
      <main className="flex-1 py-8 px-4 max-w-7xl w-full mx-auto">
        <AnimatePresence mode="wait">
          
          {/* VIEW A: ADMIN CONTROL CONSOLE */}
          {showAdminPanel ? (
            <motion.div
              key="admin-workspace"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
            >
              <AdminPanel
                config={config}
                onSaveConfig={handleSaveConfig}
                students={students}
                onAddStudent={handleAddStudent}
                onEditStudent={handleEditStudent}
                onDeleteStudent={handleDeleteStudent}
                messages={messages}
                onDeleteMessage={handleDeleteMessage}
                onClose={() => setShowAdminPanel(false)}
              />
            </motion.div>
          ) : /* VIEW B: STUDENT DETAIL DASHBOARD & TRANSCRIPT */
          selectedStudent ? (
            <motion.div
              key="student-workspace"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <StudentDashboard
                student={selectedStudent}
                config={config}
                onBack={() => setSelectedStudent(null)}
                guestbookMessages={messages}
                onAddGuestbookMessage={handleAddMessage}
                onLikeGuestbookMessage={handleLikeMessage}
              />
            </motion.div>
          ) : (
            /* VIEW C: MAIN LANDING ENTRY AND DIRECTORY SEARCH */
            <motion.div
              key="landing-workspace"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Main Greeting Banner Callout */}
              <div className="text-center space-y-3 py-6 max-w-xl mx-auto">
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-[10px] md:text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
                  🇮🇩 Pengumuman Kelulusan Resmi Online
                </span>
                <h2 className="text-3xl md:text-5xl font-black tracking-tight text-gray-900 leading-tight">
                  Pelepasan Siswa <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-800 to-teal-900">
                    Kelas IX Angkatan {config.academicYear}
                  </span>
                </h2>
                <p className="text-xs md:text-sm text-gray-500 leading-relaxed font-sans font-medium">
                  Selamat datang di Sistem Informasi Kelulusan Sekolah (SIKS) {config.schoolName}. Masukkan Nomor Induk Siswa Nasional dwi-warna Anda untuk mengakses Surat Keterangan Lulus digital.
                </p>
              </div>

              {/* Countdown Component Card */}
              <AnnouncementCountdown
                config={config}
                onCountdownComplete={() => setIsCountdownReleased(true)}
                onBypass={handleBypassCountdown}
              />

              {/* Search Box Component */}
              <StudentSearch
                students={students}
                onSelectStudent={(std) => setSelectedStudent(std)}
                countdownReleased={isCountdownReleased}
              />

              {/* Helpful instructions footer */}
              <div className="bg-white border border-gray-150 rounded-2xl max-w-md mx-auto p-4 md:p-5 shadow-sm flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center shrink-0">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-bold text-gray-900 text-xs sm:text-sm">Pusat Bantuan SIKS</h4>
                  <p className="text-[11px] sm:text-xs text-gray-500 font-sans leading-relaxed">
                    Mengalami kendala pencarian data? Hubungi Wali Kelas Anda.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Sinergy Footnotes */}
      <footer className="bg-white border-t border-gray-100 py-6 mt-12 text-center text-xs text-gray-400 font-sans print:hidden">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p>© 2026 {config.schoolName}. Seluruh Hak Cipta Dilindungi Undang-Undang.</p>
          <p className="text-[10px]">Portal Pengumuman Kelulusan Online Terintegrasi Madrasah & Kementerian Agama RI.</p>
        </div>
      </footer>
    </div>
  );
}
